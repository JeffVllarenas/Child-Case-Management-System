package childcasemanagementsystem;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

public class TableDesign {

    // ✅ Customize the appearance of any JTable 
    public static void customize(JTable table) {
        // Table cell font
        table.setFont(new java.awt.Font("Segoe UI", 0, 18));

        // Row height
        table.setRowHeight(50);

        // Borders & grid
        table.setShowGrid(false);
        table.setGridColor(Color.WHITE);
        table.setIntercellSpacing(new java.awt.Dimension(1, 1));

        // Header styling
        JTableHeader header = table.getTableHeader();
        header.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20));
        header.setBackground(new Color(255, 153, 0));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createLineBorder(Color.WHITE));

        // ✅ Center specific columns: 2 (M.I), 3 (Age), 4 (Sex), 9 (Contact #)
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        int[] centerCols = {2, 3, 4, 9};
        for (int col : centerCols) {
            if (col < table.getColumnCount()) { // prevent index errors
                table.getColumnModel().getColumn(col).setCellRenderer(centerRenderer);
            }
        }

        // Enable sorting and auto resize
        table.setAutoCreateRowSorter(true);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
    }

    // ✅ Apply neat modern scrollbar to a JScrollPane
    public static void customizeScrollBar(JScrollPane scrollPane) {
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(180, 180, 180); // Gray thumb
                this.trackColor = Color.WHITE; // Plain white background
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(thumbColor);
                g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 10, 10);
                g2.dispose();
              
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return createZeroButton();
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return createZeroButton();
            }

            private JButton createZeroButton() {
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(0, 0));
                button.setMinimumSize(new Dimension(0, 0));
                button.setMaximumSize(new Dimension(0, 0));
                return button;
            }
        });
        
        scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0)); //thin scrollbar
        
        scrollPane.getVerticalScrollBar().setUnitIncrement(10);
    }
}
