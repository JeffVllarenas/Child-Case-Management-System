
package childcasemanagementsystem;


public class Case {
    private String crime_committed;
    private String referredBy;
    private String dateReported;
   
    
    Case (String crime_committed, String referredBy, String dateReported){
     this.crime_committed = crime_committed;
     this.referredBy = referredBy;
     this.dateReported = dateReported;
     
     
     
     
    }
    String getcrimeCommmitted(){return crime_committed;}
    String getreferredBy(){return referredBy;}
    String getDateReported() {return dateReported;}
    
}    
