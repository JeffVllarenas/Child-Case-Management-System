package childcasemanagementsystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class ChildRecordsLoader {

    private static int mapCategoryToId(String category) {
        if (category == null) return 0;
        switch (category.trim().toUpperCase()) {
            case "CAR": return 1;
            case "CICL": return 2;
            case "CNSP": return 3;
            default: return 0;
        }
    }

    public static void loadRecords(String category, String keyword, JTable targetTable) {
        DefaultTableModel model = (DefaultTableModel) targetTable.getModel();
        model.setRowCount(0); // Clear table first

        int categoryId = mapCategoryToId(category);
        if (categoryId == 0) {
            JOptionPane.showMessageDialog(null, "⚠ Invalid category: " + category);
            return;
        }

        String sql;
        boolean hasResults = false; // detect if there are any results

        try (Connection conn = DBConnection.getConnection()) {

            if (keyword == null || keyword.trim().isEmpty()) {
                sql = "SELECT * FROM child_tb WHERE categoryID = ?";
                try (PreparedStatement pst = conn.prepareStatement(sql)) {
                    pst.setInt(1, categoryId);
                    try (ResultSet rs = pst.executeQuery()) {
                        while (rs.next()) {
                            hasResults = true;
                            model.addRow(new Object[]{
                                    rs.getString("Last_name"),
                                    rs.getString("First_name"),
                                    rs.getString("middleInitial"),
                                    rs.getInt("ChildAge"),
                                    rs.getString("Sex"),
                                    rs.getString("DateOfBirth"),
                                    rs.getString("EducLvlOrStatus"),
                                    rs.getString("Address"),
                                    rs.getString("Parent_name"),
                                    rs.getString("ParentContactNum")
                            });
                        }
                    }
                }
            } else {
                sql = "SELECT * FROM child_tb WHERE categoryID = ? AND (" +
                        "LOWER(Last_name) LIKE LOWER(?) OR " +
                        "LOWER(First_name) LIKE LOWER(?) OR " +
                        "LOWER(middleInitial) LIKE LOWER(?) OR " +
                        "LOWER(Parent_name) LIKE LOWER(?) OR " +
                        "LOWER(Address) LIKE LOWER(?))";

                try (PreparedStatement pst = conn.prepareStatement(sql)) {
                    pst.setInt(1, categoryId);
                    for (int i = 2; i <= 6; i++) {
                        pst.setString(i, "%" + keyword.trim() + "%");
                    }
                    try (ResultSet rs = pst.executeQuery()) {
                        while (rs.next()) {
                            hasResults = true;
                            model.addRow(new Object[]{
                                    rs.getString("Last_name"),
                                    rs.getString("First_name"),
                                    rs.getString("middleInitial"),
                                    rs.getInt("ChildAge"),
                                    rs.getString("Sex"),
                                    rs.getString("DateOfBirth"),
                                    rs.getString("EducLvlOrStatus"),
                                    rs.getString("Address"),
                                    rs.getString("Parent_name"),
                                    rs.getString("ParentContactNum")
                            });
                        }
                    }
                }
            }

           

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "❌ Error loading child records: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
