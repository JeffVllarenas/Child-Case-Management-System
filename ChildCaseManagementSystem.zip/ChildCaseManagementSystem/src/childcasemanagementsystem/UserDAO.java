package childcasemanagementsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class UserDAO {

    // ✅ Validate login with case-sensitive username
    public static boolean validateLogin(String username, String password, String role) {
        try (Connection conn = DBConnection.getConnection()) {
            // Use BINARY to make username case-sensitive
            String sql = "SELECT * FROM user WHERE BINARY username = ? AND password = ? AND role = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, username);
            pst.setString(2, password);
            pst.setString(3, role);

            ResultSet rs = pst.executeQuery();
            return rs.next(); // true if a matching record exists

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ✅ Update username & password (for single-user program)
    public static void updateCredentials(String newUsername, String newPassword) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE user SET username = ?, password = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, newUsername);
            pst.setString(2, newPassword);

            int rowsUpdated = pst.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Username and password updated successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "Update failed. Please check the database record.", "Update Failed", JOptionPane.WARNING_MESSAGE);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error updating credentials:\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
