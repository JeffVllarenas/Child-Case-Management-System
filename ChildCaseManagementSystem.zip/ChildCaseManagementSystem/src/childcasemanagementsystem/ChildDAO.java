package childcasemanagementsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class ChildDAO {

    // 🔸 Convert category name to category ID
    private static int getCategoryIdFromName(String category) {
        int categoryID = 1; // Default CAR
        if (category != null) {
            switch (category.toUpperCase()) {
                case "CICL":
                    categoryID = 2;
                    break;
                case "CNSP":
                    categoryID = 3;
                    break;
                case "CAR":
                default:
                    categoryID = 1;
                    break;
            }
        }
        return categoryID;
    }

    // 🟢 Insert a child (basic, no ID return)
    public static boolean insertChild(String lastName, String firstName, String middleInitial,
                                      int age, String sex, String dob, String educLvl,
                                      String address, String parentName, String contactNum,
                                      String category) {

        int categoryID = getCategoryIdFromName(category);

        String sql = "INSERT INTO child_tb "
                   + "(Last_name, First_name, middleInitial, ChildAge, Sex, DateOfBirth, EducLvlOrStatus, "
                   + "Address, Parent_name, ParentContactNum, categoryID) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, lastName);
            pst.setString(2, firstName);
            pst.setString(3, middleInitial);
            pst.setInt(4, age);
            pst.setString(5, sex);
            pst.setString(6, dob);
            pst.setString(7, educLvl);
            pst.setString(8, address);
            pst.setString(9, parentName);
            pst.setString(10, contactNum);
            pst.setInt(11, categoryID); // ✅ categoryID inserted

            int rowsInserted = pst.executeUpdate();
            return rowsInserted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "❌ Error adding child: " + e.getMessage());
            return false;
        }
    }

    // 🟢 Insert a child and return generated ChildID
    public static int insertChildAndGetId(String lastName, String firstName, String middleInitial,
                                          int age, String sex, String dob, String educ,
                                          String address, String parentName, String contactNum,
                                          String category) {
        int generatedId = -1;
        int categoryID = getCategoryIdFromName(category);

        String sql = "INSERT INTO child_tb "
                   + "(Last_name, First_name, middleInitial, ChildAge, Sex, DateOfBirth, EducLvlOrStatus, "
                   + "Address, Parent_name, ParentContactNum, categoryID) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pst.setString(1, lastName);
            pst.setString(2, firstName);
            pst.setString(3, middleInitial);
            pst.setInt(4, age);
            pst.setString(5, sex);
            pst.setString(6, dob);
            pst.setString(7, educ);
            pst.setString(8, address);
            pst.setString(9, parentName);
            pst.setString(10, contactNum);
            pst.setInt(11, categoryID);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet rs = pst.getGeneratedKeys()) {
                    if (rs.next()) {
                        generatedId = rs.getInt(1);
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "❌ Error adding child: " + e.getMessage());
        }

        return generatedId;
    }

}
