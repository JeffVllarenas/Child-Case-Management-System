package childcasemanagementsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JOptionPane;

public class DashBoard extends javax.swing.JFrame {

    private ArrayList<child> childList = new ArrayList<>();

    public ArrayList<child> getchildList() {
        return childList;
    }
    private ArrayList<Case> childCase = new ArrayList<>();

    private ArrayList<CNSP> CNSPdetails = new ArrayList<>();

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(DashBoard.class.getName());

    public DashBoard(String username) {

        initComponents();

        //LOADERSS
        ChildInfoLoader.loadAll(tbCAR, tbCICL, tbCNSP);
        CaseLoader.loadAllCases(tbCase);
        SearchCaseLoader searchCaseLoader = new SearchCaseLoader(tbCaseSearchField, tbCaseEnter, tbCaseReset, tbCase);
        Counter counter = new Counter();
        counter.refresh();
        SettledCounter.setText(String.valueOf(counter.getSettledCount()));
        UnsettledCounter.setText(String.valueOf(counter.getUnsettledCount()));

        //ALL ABOUT TABLES
        TableDesign.customize(tbCAR);
        TableDesign.customize(tbCICL);
        TableDesign.customize(tbCNSP);
        TableDesign.customize(ArchivedRecords);
        TableDesign.customize(RecentRecord);
        CaseTableDesign.customize(tbCase);
        TableEmptyMessage.attach(tbCAR, jScrollPaneCAR, "No record yet");
        TableEmptyMessage.attach(tbCICL, jScrollPaneCICL, "No record yet");
        TableEmptyMessage.attach(tbCNSP, jScrollPaneCNSP, "No record yet");
        TableEmptyMessage.attach(tbCase, jScrollPaneCase, "No record yet");
        TableEmptyMessage.attach(ArchivedRecords, ScrollPaneArchived, "No record yet");
        TableEmptyMessage.attach(RecentRecord, ScrollPaneRecent, "No record yet");
        TableDesign.customizeScrollBar(jScrollPaneCAR);
        TableDesign.customizeScrollBar(jScrollPaneCICL);
        TableDesign.customizeScrollBar(jScrollPaneCNSP);
        TableDesign.customizeScrollBar(ScrollPaneArchived);
        CaseTableDesign.customizeScrollBar(jScrollPaneCase);
        TableDesign.customizeScrollBar(ScrollPaneRecent);

        //ComboBoxSex
        cbSex.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"Male", "Female"}));
        //ComboBoxSex

        //FrameIcon
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/images/BANNER.png")).getImage());

        setLocationRelativeTo(null);
        tab1.setBackground(new Color(0, 153, 0));
        ChildInfo.setVisible(false);
        CaseCategory.setVisible(false);
        HearingSched.setVisible(false);
        // Start timer to update date and time
        javax.swing.Timer timer = new javax.swing.Timer(1000, (e) -> {
            java.util.Date now = new java.util.Date();

            java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("EEEE, MMMM dd, yyyy");
            java.text.SimpleDateFormat timeFormat = new java.text.SimpleDateFormat("hh:mm:ss a");

            String date = dateFormat.format(now);
            String time = timeFormat.format(now);

            // Greeting based on the hour
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.setTime(now);
            int hour = cal.get(java.util.Calendar.HOUR_OF_DAY);

            String greeting;
            if (hour >= 0 && hour < 12) {
                greeting = "Good Morning, ";
            } else if (hour >= 12 && hour < 18) {
                greeting = "Good Afternoon, ";
            } else {
                greeting = "Good Evening, ";
            }

            // Set the text with date, centered time, and greeting
            lblDateTime.setText("<html>" + "<center>" + "<i>" + greeting + " " + username + "!" + "</i>" + "</center>" + "<center>" + "<br>" + date + "</center>" + "<br>" + "<center>" + time + "</center> " + "</html>");
        });
        timer.start();

        //comboboxNIcaseCategory
        cbCategory.addItem("CAR");
        cbCategory.addItem("CICL");
        cbCategory.addItem("CNSP");

    }

    public void refreshCounters() {
        Counter counter = new Counter();
        counter.refresh();
        SettledCounter.setText(String.valueOf(counter.getSettledCount()));
        UnsettledCounter.setText(String.valueOf(counter.getUnsettledCount()));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jPasswordField1 = new javax.swing.JPasswordField();
        menuHolder = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tab1 = new javax.swing.JPanel();
        JLabel = new javax.swing.JLabel();
        tab2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        tab5 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        tab3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        tab4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        lblDateTime = new javax.swing.JLabel();
        TITLEHOLDER = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        tabContents = new javax.swing.JPanel();
        Dashboard = new javax.swing.JPanel();
        Logo = new javax.swing.JLabel();
        BrgyName = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        SubLabelBCPC = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        SettledCounter = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        MoreInfoSettled = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        UnsettledCounter = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        MoreInfoUnsettled = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        btnArchived = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        PanelRecentRecords = new javax.swing.JPanel();
        ScrollPaneRecent = new javax.swing.JScrollPane();
        RecentRecord = new javax.swing.JTable();
        PanelArchived = new javax.swing.JPanel();
        ScrollPaneArchived = new javax.swing.JScrollPane();
        ArchivedRecords = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        btnRetrieve = new javax.swing.JButton();
        User = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        Username = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jSeparator12 = new javax.swing.JSeparator();
        jSeparator13 = new javax.swing.JSeparator();
        SaveButton = new javax.swing.JButton();
        Password = new javax.swing.JPasswordField();
        AddCase = new javax.swing.JPanel();
        ChildInfo = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        tfLastName = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        tfFirstName = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        tfMiddleInitial = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        tfAge = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        cbSex = new javax.swing.JComboBox<>();
        tfEducLvl = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        tfParentName = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        dobChooser = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        taAddress = new javax.swing.JTextArea();
        jLabel21 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        tfParentContact = new javax.swing.JTextField();
        CaseCategory = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        cbCategory = new javax.swing.JComboBox<>();
        HearingSched = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        dateTimeSpinner = new javax.swing.JSpinner();
        CaseDetailsLayout4 = new javax.swing.JPanel();
        CARCaseDetails = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        tfCrimeCommittedCAR = new javax.swing.JTextField();
        jLabel60 = new javax.swing.JLabel();
        DateReportedCAR = new com.toedter.calendar.JDateChooser();
        jLabel71 = new javax.swing.JLabel();
        tfReferredByCAR = new javax.swing.JTextField();
        CICLCaseDetails = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        tfCrimeCommittedCICL = new javax.swing.JTextField();
        jLabel64 = new javax.swing.JLabel();
        tfReferredByCICL = new javax.swing.JTextField();
        jLabel65 = new javax.swing.JLabel();
        DateReportedCICL = new com.toedter.calendar.JDateChooser();
        CNSPCaseDetails = new javax.swing.JPanel();
        jLabel66 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        chbPhysicalAbuse = new javax.swing.JCheckBox();
        chbNeglect = new javax.swing.JCheckBox();
        chbPEA = new javax.swing.JCheckBox();
        chbSexualAbuse = new javax.swing.JCheckBox();
        jLabel67 = new javax.swing.JLabel();
        tfPerpetrator = new javax.swing.JTextField();
        jLabel69 = new javax.swing.JLabel();
        DateReportedCNSP = new com.toedter.calendar.JDateChooser();
        jLabel70 = new javax.swing.JLabel();
        tfReferredByCNSP = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        ManageCase = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jScrollPaneCase = new javax.swing.JScrollPane();
        tbCase = new javax.swing.JTable();
        MainCardPanel = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        PopUpPaneCAR = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        NameCAR = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        CommittedCAR = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        RefCAR = new javax.swing.JLabel();
        tfActionTakenCAR = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        cbSettledCAR = new javax.swing.JCheckBox();
        jLabel32 = new javax.swing.JLabel();
        cbUnsettledCAR = new javax.swing.JCheckBox();
        btnCAR = new javax.swing.JButton();
        PopUpPaneCICL = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        NameCICL = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jSeparator7 = new javax.swing.JSeparator();
        CommittedCICL = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jSeparator8 = new javax.swing.JSeparator();
        RefCICL = new javax.swing.JLabel();
        tfActionTakenCICL = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        cbSettledCICL = new javax.swing.JCheckBox();
        jLabel38 = new javax.swing.JLabel();
        cbUnsettledCICL = new javax.swing.JCheckBox();
        btnCICL = new javax.swing.JButton();
        PopUpPaneCNSP = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jSeparator9 = new javax.swing.JSeparator();
        perpetrator = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jSeparator10 = new javax.swing.JSeparator();
        TypeOfViolence = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jSeparator11 = new javax.swing.JSeparator();
        RefCNSP = new javax.swing.JLabel();
        tfActionTakenCNSP = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        cbSettledCNSP = new javax.swing.JCheckBox();
        jLabel44 = new javax.swing.JLabel();
        cbUnsettledCNSP = new javax.swing.JCheckBox();
        btnCNSP = new javax.swing.JButton();
        NameCNSP = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel46 = new javax.swing.JLabel();
        tbCaseSearchField = new javax.swing.JTextField();
        tbCaseEnter = new javax.swing.JLabel();
        tbCaseReset = new javax.swing.JLabel();
        ArchiveRecord1 = new javax.swing.JPanel();
        ArchiveRecords = new javax.swing.JLabel();
        tbCaseSelectAll = new javax.swing.JCheckBox();
        ChildRecord = new javax.swing.JPanel();
        crTab1 = new javax.swing.JPanel();
        CAR = new javax.swing.JLabel();
        crTab2 = new javax.swing.JPanel();
        CICL = new javax.swing.JLabel();
        crTab3 = new javax.swing.JPanel();
        CNSP = new javax.swing.JLabel();
        AddRecord = new javax.swing.JPanel();
        AddLabel = new javax.swing.JLabel();
        TableLayout = new javax.swing.JPanel();
        tbPanel1 = new javax.swing.JPanel();
        jScrollPaneCAR = new javax.swing.JScrollPane();
        tbCAR = new javax.swing.JTable();
        tbPanel2 = new javax.swing.JPanel();
        jScrollPaneCICL = new javax.swing.JScrollPane();
        tbCICL = new javax.swing.JTable();
        tbPanel3 = new javax.swing.JPanel();
        jScrollPaneCNSP = new javax.swing.JScrollPane();
        tbCNSP = new javax.swing.JTable();
        jPanel12 = new javax.swing.JPanel();
        SearchIcon = new javax.swing.JLabel();
        EnterSearch = new javax.swing.JLabel();
        SearchField = new javax.swing.JTextField();
        SelectAll = new javax.swing.JCheckBox();
        ResetSearch = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        EditRecord = new javax.swing.JLabel();

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "CASE DETAILS", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24), new java.awt.Color(0, 153, 0))); // NOI18N
        jPanel4.setOpaque(false);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 219, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 704, Short.MAX_VALUE)
        );

        jPasswordField1.setText("jPasswordField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("CHILD CASE MANAGEMENT");
        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(1520, 900));
        setResizable(false);
        getContentPane().setLayout(null);

        menuHolder.setBackground(new java.awt.Color(0, 102, 0));
        menuHolder.setPreferredSize(new java.awt.Dimension(200, 900));
        menuHolder.setLayout(null);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/GreenbgLogo (1).png"))); // NOI18N
        menuHolder.add(jLabel1);
        jLabel1.setBounds(24, 20, 170, 164);

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("BCPC Focal Person");
        menuHolder.add(jLabel2);
        jLabel2.setBounds(40, 200, 140, 20);

        tab1.setBackground(new java.awt.Color(0, 102, 0));
        tab1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tab1MouseClicked(evt);
            }
        });

        JLabel.setBackground(new java.awt.Color(255, 255, 255));
        JLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        JLabel.setForeground(new java.awt.Color(255, 255, 255));
        JLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/dashboard (1).png"))); // NOI18N
        JLabel.setText("Dashboard");

        javax.swing.GroupLayout tab1Layout = new javax.swing.GroupLayout(tab1);
        tab1.setLayout(tab1Layout);
        tab1Layout.setHorizontalGroup(
            tab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tab1Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addComponent(JLabel)
                .addGap(46, 46, 46))
        );
        tab1Layout.setVerticalGroup(
            tab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tab1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(JLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        menuHolder.add(tab1);
        tab1.setBounds(0, 250, 210, 60);

        tab2.setBackground(new java.awt.Color(0, 102, 0));
        tab2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tab2MouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/ViewRecord.png"))); // NOI18N
        jLabel4.setText("Child Record");

        javax.swing.GroupLayout tab2Layout = new javax.swing.GroupLayout(tab2);
        tab2.setLayout(tab2Layout);
        tab2Layout.setHorizontalGroup(
            tab2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tab2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel4)
                .addContainerGap(35, Short.MAX_VALUE))
        );
        tab2Layout.setVerticalGroup(
            tab2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tab2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        menuHolder.add(tab2);
        tab2.setBounds(0, 310, 210, 60);

        tab5.setBackground(new java.awt.Color(0, 102, 0));
        tab5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tab5MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tab5MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tab5MouseReleased(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logout-1.png"))); // NOI18N
        jLabel7.setText("Logout");

        javax.swing.GroupLayout tab5Layout = new javax.swing.GroupLayout(tab5);
        tab5.setLayout(tab5Layout);
        tab5Layout.setHorizontalGroup(
            tab5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tab5Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(67, Short.MAX_VALUE))
        );
        tab5Layout.setVerticalGroup(
            tab5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tab5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        menuHolder.add(tab5);
        tab5.setBounds(0, 490, 210, 60);

        tab3.setBackground(new java.awt.Color(0, 102, 0));
        tab3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tab3MouseClicked(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/AddIcon (1).png"))); // NOI18N
        jLabel5.setText("Manage Case");

        javax.swing.GroupLayout tab3Layout = new javax.swing.GroupLayout(tab3);
        tab3.setLayout(tab3Layout);
        tab3Layout.setHorizontalGroup(
            tab3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tab3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel5)
                .addContainerGap(28, Short.MAX_VALUE))
        );
        tab3Layout.setVerticalGroup(
            tab3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tab3Layout.createSequentialGroup()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 12, Short.MAX_VALUE))
        );

        menuHolder.add(tab3);
        tab3.setBounds(0, 380, 210, 50);

        tab4.setBackground(new java.awt.Color(0, 102, 0));
        tab4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tab4MouseClicked(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/User (1).png"))); // NOI18N
        jLabel6.setText("User");

        javax.swing.GroupLayout tab4Layout = new javax.swing.GroupLayout(tab4);
        tab4.setLayout(tab4Layout);
        tab4Layout.setHorizontalGroup(
            tab4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tab4Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel6)
                .addContainerGap(99, Short.MAX_VALUE))
        );
        tab4Layout.setVerticalGroup(
            tab4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tab4Layout.createSequentialGroup()
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 46, Short.MAX_VALUE)
                .addContainerGap())
        );

        menuHolder.add(tab4);
        tab4.setBounds(0, 440, 210, 50);
        menuHolder.add(jSeparator1);
        jSeparator1.setBounds(0, 230, 210, 10);

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblDateTime.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblDateTime.setForeground(new java.awt.Color(0, 102, 0));
        lblDateTime.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDateTime.setText("DATE AND TIME");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblDateTime, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblDateTime, javax.swing.GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
        );

        menuHolder.add(jPanel3);
        jPanel3.setBounds(0, 680, 210, 170);

        getContentPane().add(menuHolder);
        menuHolder.setBounds(0, 0, 210, 950);

        TITLEHOLDER.setBackground(new java.awt.Color(0, 102, 0));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("CHILD CASE MANAGEMENT SYSTEM");

        javax.swing.GroupLayout TITLEHOLDERLayout = new javax.swing.GroupLayout(TITLEHOLDER);
        TITLEHOLDER.setLayout(TITLEHOLDERLayout);
        TITLEHOLDERLayout.setHorizontalGroup(
            TITLEHOLDERLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TITLEHOLDERLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel3)
                .addContainerGap(658, Short.MAX_VALUE))
        );
        TITLEHOLDERLayout.setVerticalGroup(
            TITLEHOLDERLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TITLEHOLDERLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(15, 15, 15))
        );

        getContentPane().add(TITLEHOLDER);
        TITLEHOLDER.setBounds(200, 0, 1290, 80);

        tabContents.setBackground(new java.awt.Color(255, 255, 255));
        tabContents.setLayout(new java.awt.CardLayout());

        Dashboard.setBackground(new java.awt.Color(255, 255, 255));
        Dashboard.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        Dashboard.setPreferredSize(new java.awt.Dimension(1250, 740));

        Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/NobgLOGO (1).png"))); // NOI18N

        BrgyName.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BrgyName.setForeground(new java.awt.Color(0, 102, 0));
        BrgyName.setText("Barangay Carmen");

        SubLabelBCPC.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        SubLabelBCPC.setForeground(new java.awt.Color(0, 102, 0));
        SubLabelBCPC.setText("Barangay Council For the Protection Of Children");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210), 3));

        jPanel2.setBackground(new java.awt.Color(25, 118, 210));

        jLabel11.setFont(new java.awt.Font("Segoe UI Black", 1, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Settled Cases");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(jLabel11)
                .addContainerGap(61, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addGap(20, 20, 20))
        );

        SettledCounter.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        SettledCounter.setForeground(new java.awt.Color(25, 118, 210));
        SettledCounter.setText("0");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(166, 166, 166)
                        .addComponent(SettledCounter))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(SettledCounter)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210), 3));
        jPanel5.setRequestFocusEnabled(false);

        MoreInfoSettled.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MoreInfoSettled.setText("More Info >>");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(135, 135, 135)
                .addComponent(MoreInfoSettled)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MoreInfoSettled, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(247, 19, 19), 3));

        jPanel7.setBackground(new java.awt.Color(247, 19, 19));
        jPanel7.setPreferredSize(new java.awt.Dimension(366, 76));

        jLabel13.setFont(new java.awt.Font("Segoe UI Black", 1, 36)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Unsettled Cases");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jLabel13)
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addContainerGap(11, Short.MAX_VALUE))
        );

        UnsettledCounter.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        UnsettledCounter.setForeground(new java.awt.Color(247, 19, 19));
        UnsettledCounter.setText("0");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(172, 172, 172)
                .addComponent(UnsettledCounter)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(UnsettledCounter)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(247, 19, 19), 3));
        jPanel9.setPreferredSize(new java.awt.Dimension(255, 53));

        MoreInfoUnsettled.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MoreInfoUnsettled.setText("More Info >>");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(126, 126, 126)
                .addComponent(MoreInfoUnsettled)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MoreInfoUnsettled, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel12.setFont(new java.awt.Font("Segoe UI Black", 0, 36)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(153, 51, 0));
        jLabel12.setText("Case Summary");

        btnArchived.setBackground(new java.awt.Color(255, 153, 0));
        btnArchived.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        btnArchived.setForeground(new java.awt.Color(255, 255, 255));
        btnArchived.setText("ARCHIVED  RECORDS");
        btnArchived.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnArchivedMouseClicked(evt);
            }
        });

        jPanel15.setLayout(new java.awt.CardLayout());

        PanelRecentRecords.setBackground(new java.awt.Color(255, 255, 255));
        PanelRecentRecords.setLayout(new java.awt.BorderLayout());

        RecentRecord.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        ScrollPaneRecent.setViewportView(RecentRecord);

        PanelRecentRecords.add(ScrollPaneRecent, java.awt.BorderLayout.CENTER);

        jPanel15.add(PanelRecentRecords, "card3");

        PanelArchived.setBackground(new java.awt.Color(255, 255, 255));
        PanelArchived.setLayout(new java.awt.BorderLayout());

        ArchivedRecords.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Last Name", "FirstName", "Category", "Date Reported"
            }
        ));
        ScrollPaneArchived.setViewportView(ArchivedRecords);

        PanelArchived.add(ScrollPaneArchived, java.awt.BorderLayout.CENTER);

        jPanel15.add(PanelArchived, "card2");

        jButton1.setBackground(new java.awt.Color(255, 255, 153));
        jButton1.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(102, 102, 102));
        jButton1.setText("RECENT RECORDS");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        btnRetrieve.setBackground(new java.awt.Color(0, 102, 0));
        btnRetrieve.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        btnRetrieve.setForeground(new java.awt.Color(255, 255, 255));
        btnRetrieve.setText("Retrieve");
        btnRetrieve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetrieveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout DashboardLayout = new javax.swing.GroupLayout(Dashboard);
        Dashboard.setLayout(DashboardLayout);
        DashboardLayout.setHorizontalGroup(
            DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DashboardLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(DashboardLayout.createSequentialGroup()
                        .addComponent(Logo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(DashboardLayout.createSequentialGroup()
                                .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(BrgyName)
                                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(DashboardLayout.createSequentialGroup()
                                .addComponent(SubLabelBCPC)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel12)
                                .addGap(92, 92, 92))))
                    .addGroup(DashboardLayout.createSequentialGroup()
                        .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(DashboardLayout.createSequentialGroup()
                                .addComponent(btnArchived)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(279, 279, 279)
                                .addComponent(btnRetrieve))
                            .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 822, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, 372, Short.MAX_VALUE))
                        .addContainerGap(29, Short.MAX_VALUE))))
        );
        DashboardLayout.setVerticalGroup(
            DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DashboardLayout.createSequentialGroup()
                .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(DashboardLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(Logo))
                    .addGroup(DashboardLayout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(BrgyName)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(SubLabelBCPC, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))))
                .addGap(15, 15, 15)
                .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(DashboardLayout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(btnArchived, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(btnRetrieve))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        tabContents.add(Dashboard, "card2");

        User.setBackground(new java.awt.Color(255, 255, 255));
        User.setPreferredSize(new java.awt.Dimension(0, 740));
        User.setLayout(new java.awt.GridBagLayout());

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));
        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 0), 2, true), "Access Control", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Black", 0, 36), new java.awt.Color(255, 153, 0))); // NOI18N

        Username.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Username.setText("Enter New Username");
        Username.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UsernameMouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel9.setText("Username");

        jLabel24.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel24.setText("Password");

        SaveButton.setBackground(new java.awt.Color(0, 102, 0));
        SaveButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SaveButton.setForeground(new java.awt.Color(255, 255, 255));
        SaveButton.setText("Save");
        SaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveButtonActionPerformed(evt);
            }
        });

        Password.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(112, 112, 112)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator13, javax.swing.GroupLayout.PREFERRED_SIZE, 572, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24)
                    .addComponent(jLabel9)
                    .addComponent(jSeparator12, javax.swing.GroupLayout.PREFERRED_SIZE, 572, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(Password, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(Username, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 308, Short.MAX_VALUE)))
                .addContainerGap(116, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jSeparator12, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Username, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Password, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(jSeparator13, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(SaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(85, Short.MAX_VALUE))
        );

        User.add(jPanel14, new java.awt.GridBagConstraints());

        tabContents.add(User, "card3");

        AddCase.setBackground(new java.awt.Color(255, 255, 255));
        AddCase.setPreferredSize(new java.awt.Dimension(1250, 740));

        ChildInfo.setBackground(new java.awt.Color(255, 255, 255));
        ChildInfo.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 0), 2, true), "CHILD INFORMATION", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24), new java.awt.Color(0, 102, 0))); // NOI18N

        jLabel10.setBackground(new java.awt.Color(102, 255, 51));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 102, 0));
        jLabel10.setText("Last Name");

        tfLastName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfLastName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 102, 0));
        jLabel14.setText("First Name");

        tfFirstName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfFirstName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 102, 0));
        jLabel15.setText("Middle Initial");

        tfMiddleInitial.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfMiddleInitial.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 102, 0));
        jLabel16.setText("Age");

        tfAge.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfAge.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 102, 0));
        jLabel17.setText("Sex");

        cbSex.setEditable(true);
        cbSex.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cbSex.setOpaque(true);
        cbSex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSexActionPerformed(evt);
            }
        });

        tfEducLvl.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfEducLvl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 102, 0));
        jLabel18.setText("Educational Level/Status");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 102, 0));
        jLabel19.setText("Parent's/Guardian's Name");

        tfParentName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfParentName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel20.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 102, 0));
        jLabel20.setText("Date of Birth");

        dobChooser.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        taAddress.setColumns(20);
        taAddress.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        taAddress.setRows(5);
        jScrollPane1.setViewportView(taAddress);

        jLabel21.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 102, 0));
        jLabel21.setText("Address");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 102, 0));
        jLabel23.setText("Guardian's Contact #");

        tfParentContact.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfParentContact.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        tfParentContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfParentContactActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ChildInfoLayout = new javax.swing.GroupLayout(ChildInfo);
        ChildInfo.setLayout(ChildInfoLayout);
        ChildInfoLayout.setHorizontalGroup(
            ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ChildInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ChildInfoLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(233, 233, 233)
                        .addComponent(jLabel14)
                        .addGap(221, 221, 221)
                        .addComponent(jLabel15))
                    .addGroup(ChildInfoLayout.createSequentialGroup()
                        .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16))
                        .addGap(18, 18, 18)
                        .addComponent(tfFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfMiddleInitial, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(ChildInfoLayout.createSequentialGroup()
                        .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ChildInfoLayout.createSequentialGroup()
                                .addComponent(tfAge, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dobChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel20))
                                .addGap(18, 18, 18)
                                .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel17)
                                    .addComponent(cbSex, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel21)))
                            .addComponent(jLabel19))
                        .addGap(6, 6, 6)
                        .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18)
                            .addComponent(tfEducLvl, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(ChildInfoLayout.createSequentialGroup()
                        .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfParentName, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel23)
                            .addComponent(tfParentContact, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19)
                        .addComponent(jScrollPane1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        ChildInfoLayout.setVerticalGroup(
            ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ChildInfoLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel14)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfMiddleInitial, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel20, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(jLabel18)))
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfAge, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dobChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cbSex, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tfEducLvl, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19)
                    .addComponent(jLabel21))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChildInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(ChildInfoLayout.createSequentialGroup()
                        .addComponent(tfParentName, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel23)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfParentContact, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1))
                .addContainerGap(80, Short.MAX_VALUE))
        );

        CaseCategory.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 153), 2, true), "CASE CATEGORY", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24), new java.awt.Color(0, 102, 0))); // NOI18N
        CaseCategory.setOpaque(false);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 102, 0));
        jLabel8.setText("Category:");

        cbCategory.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cbCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbCategoryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout CaseCategoryLayout = new javax.swing.GroupLayout(CaseCategory);
        CaseCategory.setLayout(CaseCategoryLayout);
        CaseCategoryLayout.setHorizontalGroup(
            CaseCategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CaseCategoryLayout.createSequentialGroup()
                .addGap(102, 102, 102)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addComponent(cbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        CaseCategoryLayout.setVerticalGroup(
            CaseCategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CaseCategoryLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(CaseCategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)))
        );

        HearingSched.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102), 2), "SET HEARING SCHEDULE", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24), new java.awt.Color(0, 102, 0))); // NOI18N
        HearingSched.setOpaque(false);

        jLabel28.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 102, 0));
        jLabel28.setText("Date and Time:");

        dateTimeSpinner.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        dateTimeSpinner.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(), null, null, java.util.Calendar.AM_PM));

        javax.swing.GroupLayout HearingSchedLayout = new javax.swing.GroupLayout(HearingSched);
        HearingSched.setLayout(HearingSchedLayout);
        HearingSchedLayout.setHorizontalGroup(
            HearingSchedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HearingSchedLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dateTimeSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65))
        );
        HearingSchedLayout.setVerticalGroup(
            HearingSchedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HearingSchedLayout.createSequentialGroup()
                .addGroup(HearingSchedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateTimeSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel28))
                .addGap(0, 6, Short.MAX_VALUE))
        );

        CaseDetailsLayout4.setLayout(new java.awt.CardLayout());

        CARCaseDetails.setBackground(new java.awt.Color(255, 255, 255));
        CARCaseDetails.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 0), 2), "CASE DETAILS", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24), new java.awt.Color(0, 102, 0))); // NOI18N

        jLabel56.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(0, 102, 0));
        jLabel56.setText("Crime Committed: ");

        tfCrimeCommittedCAR.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfCrimeCommittedCAR.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel60.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(0, 102, 0));
        jLabel60.setText("Date Reported:");

        DateReportedCAR.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        jLabel71.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel71.setForeground(new java.awt.Color(0, 102, 0));
        jLabel71.setText("Referred by:");

        tfReferredByCAR.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfReferredByCAR.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        tfReferredByCAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfReferredByCARActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout CARCaseDetailsLayout = new javax.swing.GroupLayout(CARCaseDetails);
        CARCaseDetails.setLayout(CARCaseDetailsLayout);
        CARCaseDetailsLayout.setHorizontalGroup(
            CARCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CARCaseDetailsLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(CARCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel60)
                    .addComponent(jLabel56)
                    .addComponent(jLabel71))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CARCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(tfReferredByCAR, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfCrimeCommittedCAR, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DateReportedCAR, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        CARCaseDetailsLayout.setVerticalGroup(
            CARCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CARCaseDetailsLayout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(CARCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel56)
                    .addComponent(tfCrimeCommittedCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addGroup(CARCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel71)
                    .addComponent(tfReferredByCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(CARCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CARCaseDetailsLayout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jLabel60))
                    .addGroup(CARCaseDetailsLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(DateReportedCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(33, 33, 33))
        );

        CaseDetailsLayout4.add(CARCaseDetails, "card4");

        CICLCaseDetails.setBackground(new java.awt.Color(255, 255, 255));
        CICLCaseDetails.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 0, 153), 2), "CASE DETAILS", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24), new java.awt.Color(0, 102, 0))); // NOI18N

        jLabel61.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(0, 102, 0));
        jLabel61.setText("Crime Committed:");

        tfCrimeCommittedCICL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfCrimeCommittedCICL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel64.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(0, 102, 0));
        jLabel64.setText("Date Reported:");

        tfReferredByCICL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfReferredByCICL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel65.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel65.setForeground(new java.awt.Color(0, 102, 0));
        jLabel65.setText("Referred by:");

        DateReportedCICL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        javax.swing.GroupLayout CICLCaseDetailsLayout = new javax.swing.GroupLayout(CICLCaseDetails);
        CICLCaseDetails.setLayout(CICLCaseDetailsLayout);
        CICLCaseDetailsLayout.setHorizontalGroup(
            CICLCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CICLCaseDetailsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(CICLCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel61)
                    .addComponent(jLabel65)
                    .addComponent(jLabel64))
                .addGap(18, 18, 18)
                .addGroup(CICLCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DateReportedCICL, javax.swing.GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE)
                    .addComponent(tfCrimeCommittedCICL)
                    .addComponent(tfReferredByCICL))
                .addGap(22, 22, 22))
        );
        CICLCaseDetailsLayout.setVerticalGroup(
            CICLCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CICLCaseDetailsLayout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(CICLCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel61)
                    .addComponent(tfCrimeCommittedCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(CICLCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CICLCaseDetailsLayout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(CICLCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tfReferredByCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel65))
                        .addGap(18, 18, 18)
                        .addComponent(DateReportedCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(CICLCaseDetailsLayout.createSequentialGroup()
                        .addGap(137, 137, 137)
                        .addComponent(jLabel64)))
                .addGap(35, 35, Short.MAX_VALUE))
        );

        CaseDetailsLayout4.add(CICLCaseDetails, "card3");

        CNSPCaseDetails.setBackground(new java.awt.Color(255, 255, 255));
        CNSPCaseDetails.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 51, 153), 2, true), "CASE DETAILS", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24), new java.awt.Color(0, 102, 0))); // NOI18N

        jLabel66.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(0, 102, 0));
        jLabel66.setText("Types of Violence:");

        chbPhysicalAbuse.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        chbPhysicalAbuse.setText("Physical Abuse");
        chbPhysicalAbuse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chbPhysicalAbuseActionPerformed(evt);
            }
        });

        chbNeglect.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        chbNeglect.setText("Neglect");
        chbNeglect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chbNeglectActionPerformed(evt);
            }
        });

        chbPEA.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        chbPEA.setText("Psychological Emotional Abuse");
        chbPEA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chbPEAActionPerformed(evt);
            }
        });

        chbSexualAbuse.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        chbSexualAbuse.setText("Sexual Abuse");
        chbSexualAbuse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chbSexualAbuseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(chbPhysicalAbuse)
                        .addGap(18, 18, 18)
                        .addComponent(chbSexualAbuse))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(chbPEA)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(chbNeglect)))
                .addGap(19, 19, 19))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chbPhysicalAbuse)
                    .addComponent(chbSexualAbuse))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chbPEA)
                    .addComponent(chbNeglect))
                .addContainerGap(7, Short.MAX_VALUE))
        );

        jLabel67.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel67.setForeground(new java.awt.Color(0, 102, 0));
        jLabel67.setText("Perpetrator:");

        tfPerpetrator.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfPerpetrator.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel69.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel69.setForeground(new java.awt.Color(0, 102, 0));
        jLabel69.setText("Date Reported:");

        DateReportedCNSP.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        jLabel70.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(0, 102, 0));
        jLabel70.setText("Referred by:");

        tfReferredByCNSP.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfReferredByCNSP.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        javax.swing.GroupLayout CNSPCaseDetailsLayout = new javax.swing.GroupLayout(CNSPCaseDetails);
        CNSPCaseDetails.setLayout(CNSPCaseDetailsLayout);
        CNSPCaseDetailsLayout.setHorizontalGroup(
            CNSPCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CNSPCaseDetailsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(CNSPCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, CNSPCaseDetailsLayout.createSequentialGroup()
                        .addComponent(jLabel70)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfReferredByCNSP, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(CNSPCaseDetailsLayout.createSequentialGroup()
                        .addGroup(CNSPCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel66)
                            .addComponent(tfPerpetrator, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel67))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CNSPCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(DateReportedCNSP, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel69))
                        .addGap(12, 12, 12))
                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(8, Short.MAX_VALUE))
        );
        CNSPCaseDetailsLayout.setVerticalGroup(
            CNSPCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CNSPCaseDetailsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel66)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CNSPCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(CNSPCaseDetailsLayout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(CNSPCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel67)
                            .addComponent(jLabel69))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfPerpetrator, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(DateReportedCNSP, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(CNSPCaseDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfReferredByCNSP, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel70))
                .addGap(0, 13, Short.MAX_VALUE))
        );

        CaseDetailsLayout4.add(CNSPCaseDetails, "card2");

        btnAdd.setBackground(new java.awt.Color(0, 102, 0));
        btnAdd.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnAdd.setForeground(new java.awt.Color(255, 255, 255));
        btnAdd.setText("ADD");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnClear.setBackground(new java.awt.Color(204, 204, 204));
        btnClear.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("CLEAR");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout AddCaseLayout = new javax.swing.GroupLayout(AddCase);
        AddCase.setLayout(AddCaseLayout);
        AddCaseLayout.setHorizontalGroup(
            AddCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AddCaseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ChildInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(AddCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AddCaseLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(72, 72, 72))
                    .addGroup(AddCaseLayout.createSequentialGroup()
                        .addGroup(AddCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(CaseCategory, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(HearingSched, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(71, Short.MAX_VALUE))))
            .addGroup(AddCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(AddCaseLayout.createSequentialGroup()
                    .addGap(796, 796, 796)
                    .addComponent(CaseDetailsLayout4, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(54, Short.MAX_VALUE)))
        );
        AddCaseLayout.setVerticalGroup(
            AddCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AddCaseLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addGroup(AddCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AddCaseLayout.createSequentialGroup()
                        .addComponent(CaseCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(HearingSched, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(ChildInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(AddCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(96, 96, 96))
            .addGroup(AddCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(AddCaseLayout.createSequentialGroup()
                    .addGap(170, 170, 170)
                    .addComponent(CaseDetailsLayout4, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(258, Short.MAX_VALUE)))
        );

        tabContents.add(AddCase, "card4");

        ManageCase.setBackground(new java.awt.Color(255, 255, 255));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 102, 0));
        jLabel22.setText("CASE MANAGEMENT");

        jScrollPaneCase.setOpaque(false);

        tbCase.setBackground(new java.awt.Color(245, 245, 245));
        tbCase.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Case No.", "Child Name", "Case Category", "Date Reported", "Status", "Action Taken"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbCase.setOpaque(false);
        tbCase.setSelectionBackground(new java.awt.Color(204, 255, 204));
        tbCase.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbCaseMouseClicked(evt);
            }
        });
        jScrollPaneCase.setViewportView(tbCase);
        if (tbCase.getColumnModel().getColumnCount() > 0) {
            tbCase.getColumnModel().getColumn(0).setPreferredWidth(60);
            tbCase.getColumnModel().getColumn(1).setPreferredWidth(200);
            tbCase.getColumnModel().getColumn(2).setPreferredWidth(120);
        }

        MainCardPanel.setBackground(new java.awt.Color(255, 255, 255));
        MainCardPanel.setLayout(new java.awt.CardLayout());

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 204, 153), 1, true));

        jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/briefcase (1).png"))); // NOI18N

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(164, 164, 164)
                .addComponent(jLabel45)
                .addContainerGap(170, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(280, 280, 280)
                .addComponent(jLabel45)
                .addContainerGap(330, Short.MAX_VALUE))
        );

        MainCardPanel.add(jPanel11, "card2");

        PopUpPaneCAR.setBackground(new java.awt.Color(255, 255, 255));
        PopUpPaneCAR.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 0), 2, true));

        jLabel25.setFont(new java.awt.Font("Perpetua Titling MT", 1, 36)); // NOI18N
        jLabel25.setText("Case Details");

        jLabel26.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(0, 102, 0));
        jLabel26.setText("Name");

        jSeparator3.setBackground(new java.awt.Color(255, 255, 255));

        NameCAR.setFont(new java.awt.Font("Segoe UI", 2, 18)); // NOI18N
        NameCAR.setText("Name");

        jLabel29.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(0, 102, 0));
        jLabel29.setText("Crime Commited");

        jSeparator4.setBackground(new java.awt.Color(255, 255, 255));

        CommittedCAR.setFont(new java.awt.Font("Segoe UI", 2, 18)); // NOI18N
        CommittedCAR.setText("Committed Cyber  ");

        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(0, 102, 0));
        jLabel30.setText("Referred By");

        jSeparator5.setBackground(new java.awt.Color(255, 255, 255));

        RefCAR.setFont(new java.awt.Font("Segoe UI", 2, 18)); // NOI18N
        RefCAR.setText("ReferredBy");
        RefCAR.setMaximumSize(new java.awt.Dimension(88, 18));
        RefCAR.setMinimumSize(new java.awt.Dimension(88, 18));
        RefCAR.setPreferredSize(new java.awt.Dimension(88, 18));

        tfActionTakenCAR.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfActionTakenCAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfActionTakenCARActionPerformed(evt);
            }
        });

        jLabel31.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(0, 102, 0));
        jLabel31.setText("Action Taken");

        cbSettledCAR.setBackground(new java.awt.Color(255, 255, 255));
        cbSettledCAR.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cbSettledCAR.setForeground(new java.awt.Color(0, 102, 0));
        cbSettledCAR.setText("Settled");
        cbSettledCAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSettledCARActionPerformed(evt);
            }
        });

        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(0, 102, 0));
        jLabel32.setText("Case Status");

        cbUnsettledCAR.setBackground(new java.awt.Color(255, 255, 255));
        cbUnsettledCAR.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cbUnsettledCAR.setForeground(new java.awt.Color(0, 102, 0));
        cbUnsettledCAR.setText("Unsettled");
        cbUnsettledCAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbUnsettledCARActionPerformed(evt);
            }
        });

        btnCAR.setBackground(new java.awt.Color(0, 102, 0));
        btnCAR.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        btnCAR.setForeground(new java.awt.Color(255, 255, 255));
        btnCAR.setText("UPDATE");
        btnCAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCARActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PopUpPaneCARLayout = new javax.swing.GroupLayout(PopUpPaneCAR);
        PopUpPaneCAR.setLayout(PopUpPaneCARLayout);
        PopUpPaneCARLayout.setHorizontalGroup(
            PopUpPaneCARLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PopUpPaneCARLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(PopUpPaneCARLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnCAR)
                    .addGroup(PopUpPaneCARLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(tfActionTakenCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(RefCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(CommittedCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(PopUpPaneCARLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jSeparator4, javax.swing.GroupLayout.DEFAULT_SIZE, 169, Short.MAX_VALUE)
                            .addComponent(jSeparator3))
                        .addComponent(NameCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(PopUpPaneCARLayout.createSequentialGroup()
                            .addGap(45, 45, 45)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(PopUpPaneCARLayout.createSequentialGroup()
                            .addComponent(cbSettledCAR)
                            .addGap(18, 18, 18)
                            .addComponent(cbUnsettledCAR))))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        PopUpPaneCARLayout.setVerticalGroup(
            PopUpPaneCARLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PopUpPaneCARLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel25)
                .addGap(18, 18, 18)
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(NameCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CommittedCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RefCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PopUpPaneCARLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbSettledCAR)
                    .addComponent(cbUnsettledCAR))
                .addGap(18, 18, 18)
                .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfActionTakenCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 101, Short.MAX_VALUE)
                .addComponent(btnCAR, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        MainCardPanel.add(PopUpPaneCAR, "card3");

        PopUpPaneCICL.setBackground(new java.awt.Color(255, 255, 255));
        PopUpPaneCICL.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));

        jLabel27.setFont(new java.awt.Font("Perpetua Titling MT", 1, 36)); // NOI18N
        jLabel27.setText("Case Details");

        jLabel33.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(0, 102, 0));
        jLabel33.setText("Name");

        jSeparator6.setBackground(new java.awt.Color(255, 255, 255));

        NameCICL.setFont(new java.awt.Font("Segoe UI", 2, 18)); // NOI18N
        NameCICL.setText("Name");

        jLabel35.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(0, 102, 0));
        jLabel35.setText("Crime Commited");

        jSeparator7.setBackground(new java.awt.Color(255, 255, 255));

        CommittedCICL.setFont(new java.awt.Font("Segoe UI", 2, 18)); // NOI18N
        CommittedCICL.setText("Committed Cyber  ");

        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(0, 102, 0));
        jLabel36.setText("Referred By");

        jSeparator8.setBackground(new java.awt.Color(255, 255, 255));
        jSeparator8.setOpaque(true);

        RefCICL.setFont(new java.awt.Font("Segoe UI", 2, 18)); // NOI18N
        RefCICL.setText("ReferredBy");
        RefCICL.setMaximumSize(new java.awt.Dimension(88, 18));
        RefCICL.setMinimumSize(new java.awt.Dimension(88, 18));
        RefCICL.setPreferredSize(new java.awt.Dimension(88, 18));

        tfActionTakenCICL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfActionTakenCICL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfActionTakenCICLActionPerformed(evt);
            }
        });

        jLabel37.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(0, 102, 0));
        jLabel37.setText("Action Taken");

        cbSettledCICL.setBackground(new java.awt.Color(255, 255, 255));
        cbSettledCICL.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cbSettledCICL.setForeground(new java.awt.Color(0, 102, 0));
        cbSettledCICL.setText("Settled");
        cbSettledCICL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSettledCICLActionPerformed(evt);
            }
        });

        jLabel38.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(0, 102, 0));
        jLabel38.setText("Case Status");

        cbUnsettledCICL.setBackground(new java.awt.Color(255, 255, 255));
        cbUnsettledCICL.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cbUnsettledCICL.setForeground(new java.awt.Color(0, 102, 0));
        cbUnsettledCICL.setText("Unsettled");
        cbUnsettledCICL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbUnsettledCICLActionPerformed(evt);
            }
        });

        btnCICL.setBackground(new java.awt.Color(0, 102, 0));
        btnCICL.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        btnCICL.setForeground(new java.awt.Color(255, 255, 255));
        btnCICL.setText("UPDATE");
        btnCICL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCICLActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PopUpPaneCICLLayout = new javax.swing.GroupLayout(PopUpPaneCICL);
        PopUpPaneCICL.setLayout(PopUpPaneCICLLayout);
        PopUpPaneCICLLayout.setHorizontalGroup(
            PopUpPaneCICLLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PopUpPaneCICLLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(PopUpPaneCICLLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnCICL)
                    .addGroup(PopUpPaneCICLLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(tfActionTakenCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(RefCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(CommittedCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(PopUpPaneCICLLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jSeparator7, javax.swing.GroupLayout.DEFAULT_SIZE, 169, Short.MAX_VALUE)
                            .addComponent(jSeparator6))
                        .addComponent(NameCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(PopUpPaneCICLLayout.createSequentialGroup()
                            .addGap(45, 45, 45)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(PopUpPaneCICLLayout.createSequentialGroup()
                            .addComponent(cbSettledCICL)
                            .addGap(18, 18, 18)
                            .addComponent(cbUnsettledCICL))))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        PopUpPaneCICLLayout.setVerticalGroup(
            PopUpPaneCICLLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PopUpPaneCICLLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel27)
                .addGap(18, 18, 18)
                .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(NameCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CommittedCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RefCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PopUpPaneCICLLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbSettledCICL)
                    .addComponent(cbUnsettledCICL))
                .addGap(18, 18, 18)
                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfActionTakenCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 101, Short.MAX_VALUE)
                .addComponent(btnCICL, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        MainCardPanel.add(PopUpPaneCICL, "card3");

        PopUpPaneCNSP.setBackground(new java.awt.Color(255, 255, 255));
        PopUpPaneCNSP.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 153), 2, true));

        jLabel39.setFont(new java.awt.Font("Perpetua Titling MT", 1, 36)); // NOI18N
        jLabel39.setText("Case Details");

        jLabel40.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(0, 102, 0));
        jLabel40.setText("Perpetrator");

        jSeparator9.setBackground(new java.awt.Color(255, 255, 255));

        perpetrator.setFont(new java.awt.Font("Segoe UI", 2, 18)); // NOI18N
        perpetrator.setText("Name");

        jLabel41.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(0, 102, 0));
        jLabel41.setText("Type Of Violence");

        jSeparator10.setBackground(new java.awt.Color(255, 255, 255));

        TypeOfViolence.setFont(new java.awt.Font("Segoe UI", 2, 18)); // NOI18N
        TypeOfViolence.setText("Committed Cyber  ");

        jLabel42.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(0, 102, 0));
        jLabel42.setText("Referred By");

        jSeparator11.setBackground(new java.awt.Color(255, 255, 255));

        RefCNSP.setFont(new java.awt.Font("Segoe UI", 2, 18)); // NOI18N
        RefCNSP.setText("ReferredBy");
        RefCNSP.setMaximumSize(new java.awt.Dimension(88, 18));
        RefCNSP.setMinimumSize(new java.awt.Dimension(88, 18));
        RefCNSP.setPreferredSize(new java.awt.Dimension(88, 18));

        tfActionTakenCNSP.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfActionTakenCNSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfActionTakenCNSPActionPerformed(evt);
            }
        });

        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(0, 102, 0));
        jLabel43.setText("Action Taken");

        cbSettledCNSP.setBackground(new java.awt.Color(255, 255, 255));
        cbSettledCNSP.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cbSettledCNSP.setForeground(new java.awt.Color(0, 102, 0));
        cbSettledCNSP.setText("Settled");
        cbSettledCNSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSettledCNSPActionPerformed(evt);
            }
        });

        jLabel44.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(0, 102, 0));
        jLabel44.setText("Case Status");

        cbUnsettledCNSP.setBackground(new java.awt.Color(255, 255, 255));
        cbUnsettledCNSP.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cbUnsettledCNSP.setForeground(new java.awt.Color(0, 102, 0));
        cbUnsettledCNSP.setText("Unsettled");
        cbUnsettledCNSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbUnsettledCNSPActionPerformed(evt);
            }
        });

        btnCNSP.setBackground(new java.awt.Color(0, 102, 0));
        btnCNSP.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        btnCNSP.setForeground(new java.awt.Color(255, 255, 255));
        btnCNSP.setText("UPDATE");
        btnCNSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCNSPActionPerformed(evt);
            }
        });

        NameCNSP.setFont(new java.awt.Font("Segoe UI", 2, 18)); // NOI18N
        NameCNSP.setForeground(new java.awt.Color(255, 255, 255));
        NameCNSP.setText("jLabel24");

        javax.swing.GroupLayout PopUpPaneCNSPLayout = new javax.swing.GroupLayout(PopUpPaneCNSP);
        PopUpPaneCNSP.setLayout(PopUpPaneCNSPLayout);
        PopUpPaneCNSPLayout.setHorizontalGroup(
            PopUpPaneCNSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PopUpPaneCNSPLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(PopUpPaneCNSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnCNSP)
                    .addGroup(PopUpPaneCNSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(tfActionTakenCNSP, javax.swing.GroupLayout.DEFAULT_SIZE, 344, Short.MAX_VALUE)
                        .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSeparator11, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(PopUpPaneCNSPLayout.createSequentialGroup()
                            .addGap(45, 45, 45)
                            .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(PopUpPaneCNSPLayout.createSequentialGroup()
                            .addComponent(cbSettledCNSP)
                            .addGap(18, 18, 18)
                            .addComponent(cbUnsettledCNSP))
                        .addComponent(perpetrator, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(TypeOfViolence, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(RefCNSP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(NameCNSP, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        PopUpPaneCNSPLayout.setVerticalGroup(
            PopUpPaneCNSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PopUpPaneCNSPLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel39)
                .addGap(18, 18, 18)
                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(perpetrator, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TypeOfViolence, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RefCNSP, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PopUpPaneCNSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbSettledCNSP)
                    .addComponent(cbUnsettledCNSP))
                .addGap(18, 18, 18)
                .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfActionTakenCNSP, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(NameCNSP)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addComponent(btnCNSP, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        MainCardPanel.add(PopUpPaneCNSP, "card3");

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jPanel10.setLayout(new java.awt.BorderLayout());

        jLabel46.setBackground(new java.awt.Color(255, 255, 255));
        jLabel46.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/tool (1).png"))); // NOI18N
        jPanel10.add(jLabel46, java.awt.BorderLayout.LINE_START);

        tbCaseSearchField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tbCaseSearchField.setText("Search");
        tbCaseSearchField.setBorder(null);
        jPanel10.add(tbCaseSearchField, java.awt.BorderLayout.CENTER);

        tbCaseEnter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/enter-1.png"))); // NOI18N
        tbCaseEnter.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jPanel10.add(tbCaseEnter, java.awt.BorderLayout.LINE_END);

        tbCaseReset.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/recycle (1).png"))); // NOI18N
        tbCaseReset.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        ArchiveRecord1.setBackground(new java.awt.Color(255, 255, 255));
        ArchiveRecord1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 0)));
        ArchiveRecord1.setPreferredSize(new java.awt.Dimension(150, 50));
        ArchiveRecord1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ArchiveRecord1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ArchiveRecord1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ArchiveRecord1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ArchiveRecord1MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                ArchiveRecord1MouseReleased(evt);
            }
        });

        ArchiveRecords.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        ArchiveRecords.setForeground(new java.awt.Color(0, 102, 0));
        ArchiveRecords.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/archives (1).png"))); // NOI18N
        ArchiveRecords.setText("ARCHIVE");
        ArchiveRecords.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ArchiveRecordsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout ArchiveRecord1Layout = new javax.swing.GroupLayout(ArchiveRecord1);
        ArchiveRecord1.setLayout(ArchiveRecord1Layout);
        ArchiveRecord1Layout.setHorizontalGroup(
            ArchiveRecord1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ArchiveRecord1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ArchiveRecords, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );
        ArchiveRecord1Layout.setVerticalGroup(
            ArchiveRecord1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ArchiveRecords, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
        );

        tbCaseSelectAll.setBackground(new java.awt.Color(255, 255, 255));
        tbCaseSelectAll.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        tbCaseSelectAll.setForeground(new java.awt.Color(0, 102, 0));
        tbCaseSelectAll.setText("Select All");
        tbCaseSelectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbCaseSelectAllActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ManageCaseLayout = new javax.swing.GroupLayout(ManageCase);
        ManageCase.setLayout(ManageCaseLayout);
        ManageCaseLayout.setHorizontalGroup(
            ManageCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ManageCaseLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(ManageCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, ManageCaseLayout.createSequentialGroup()
                        .addComponent(jLabel22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tbCaseReset)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPaneCase, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 825, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(ManageCaseLayout.createSequentialGroup()
                        .addComponent(tbCaseSelectAll)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ArchiveRecord1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(12, 12, 12)
                .addComponent(MainCardPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        ManageCaseLayout.setVerticalGroup(
            ManageCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ManageCaseLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(ManageCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tbCaseReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ManageCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ManageCaseLayout.createSequentialGroup()
                        .addComponent(jScrollPaneCase, javax.swing.GroupLayout.PREFERRED_SIZE, 578, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(ManageCaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ArchiveRecord1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tbCaseSelectAll)))
                    .addComponent(MainCardPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabContents.add(ManageCase, "card6");

        ChildRecord.setBackground(new java.awt.Color(255, 255, 255));
        ChildRecord.setPreferredSize(new java.awt.Dimension(1244, 740));

        crTab1.setBackground(new java.awt.Color(0, 102, 0));
        crTab1.setPreferredSize(new java.awt.Dimension(160, 50));
        crTab1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                crTab1MouseClicked(evt);
            }
        });

        CAR.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        CAR.setForeground(new java.awt.Color(255, 255, 255));
        CAR.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CAR.setText("CAR");

        javax.swing.GroupLayout crTab1Layout = new javax.swing.GroupLayout(crTab1);
        crTab1.setLayout(crTab1Layout);
        crTab1Layout.setHorizontalGroup(
            crTab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(CAR, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
        );
        crTab1Layout.setVerticalGroup(
            crTab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(CAR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        crTab2.setBackground(new java.awt.Color(255, 255, 255));
        crTab2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        crTab2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                crTab2MouseClicked(evt);
            }
        });

        CICL.setBackground(new java.awt.Color(255, 255, 255));
        CICL.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        CICL.setForeground(new java.awt.Color(0, 102, 0));
        CICL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CICL.setText("CICL");

        javax.swing.GroupLayout crTab2Layout = new javax.swing.GroupLayout(crTab2);
        crTab2.setLayout(crTab2Layout);
        crTab2Layout.setHorizontalGroup(
            crTab2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(CICL, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
        );
        crTab2Layout.setVerticalGroup(
            crTab2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(CICL, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
        );

        crTab3.setBackground(new java.awt.Color(255, 255, 255));
        crTab3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        crTab3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                crTab3MouseClicked(evt);
            }
        });

        CNSP.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        CNSP.setForeground(new java.awt.Color(0, 102, 0));
        CNSP.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CNSP.setText("CNSP");

        javax.swing.GroupLayout crTab3Layout = new javax.swing.GroupLayout(crTab3);
        crTab3.setLayout(crTab3Layout);
        crTab3Layout.setHorizontalGroup(
            crTab3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(crTab3Layout.createSequentialGroup()
                .addComponent(CNSP, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        crTab3Layout.setVerticalGroup(
            crTab3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(CNSP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        AddRecord.setBackground(new java.awt.Color(0, 102, 0));
        AddRecord.setPreferredSize(new java.awt.Dimension(217, 50));
        AddRecord.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddRecordMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                AddRecordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                AddRecordMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                AddRecordMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                AddRecordMouseReleased(evt);
            }
        });

        AddLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        AddLabel.setForeground(new java.awt.Color(255, 255, 255));
        AddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/add (1).png"))); // NOI18N
        AddLabel.setText("ADD NEW RECORD");

        javax.swing.GroupLayout AddRecordLayout = new javax.swing.GroupLayout(AddRecord);
        AddRecord.setLayout(AddRecordLayout);
        AddRecordLayout.setHorizontalGroup(
            AddRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AddRecordLayout.createSequentialGroup()
                .addComponent(AddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 7, Short.MAX_VALUE))
        );
        AddRecordLayout.setVerticalGroup(
            AddRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AddRecordLayout.createSequentialGroup()
                .addComponent(AddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        TableLayout.setLayout(new java.awt.CardLayout());

        tbCAR.setBackground(new java.awt.Color(245, 245, 245));
        tbCAR.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tbCAR.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "LastName", "FirstName", "M.I", "Age", "Sex", "Date Of Birth", "Educational Level/Status", "Address", "Guardian's Name", "Contact #"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbCAR.setToolTipText(" ");
        tbCAR.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tbCAR.setGridColor(new java.awt.Color(255, 255, 255));
        tbCAR.setOpaque(false);
        tbCAR.setRowHeight(50);
        tbCAR.setSelectionBackground(new java.awt.Color(255, 255, 255));
        tbCAR.setSelectionForeground(new java.awt.Color(255, 0, 0));
        tbCAR.setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        jScrollPaneCAR.setViewportView(tbCAR);
        if (tbCAR.getColumnModel().getColumnCount() > 0) {
            tbCAR.getColumnModel().getColumn(2).setPreferredWidth(5);
            tbCAR.getColumnModel().getColumn(3).setPreferredWidth(10);
            tbCAR.getColumnModel().getColumn(4).setPreferredWidth(50);
            tbCAR.getColumnModel().getColumn(6).setPreferredWidth(100);
            tbCAR.getColumnModel().getColumn(7).setPreferredWidth(200);
        }

        javax.swing.GroupLayout tbPanel1Layout = new javax.swing.GroupLayout(tbPanel1);
        tbPanel1.setLayout(tbPanel1Layout);
        tbPanel1Layout.setHorizontalGroup(
            tbPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPaneCAR, javax.swing.GroupLayout.DEFAULT_SIZE, 1221, Short.MAX_VALUE)
        );
        tbPanel1Layout.setVerticalGroup(
            tbPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPaneCAR, javax.swing.GroupLayout.DEFAULT_SIZE, 578, Short.MAX_VALUE)
        );

        TableLayout.add(tbPanel1, "card2");

        tbCICL.setBackground(new java.awt.Color(245, 245, 245));
        tbCICL.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "LastName", "FirstName", "Middle Initial", "Age", "Sex", "Date of Birth", "Educational Level/Status", "Address", "Guardian's Name", "Contact #"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbCICL.setOpaque(false);
        tbCICL.setSelectionBackground(new java.awt.Color(255, 255, 255));
        tbCICL.setSelectionForeground(new java.awt.Color(153, 0, 153));
        jScrollPaneCICL.setViewportView(tbCICL);
        if (tbCICL.getColumnModel().getColumnCount() > 0) {
            tbCICL.getColumnModel().getColumn(6).setPreferredWidth(100);
        }

        javax.swing.GroupLayout tbPanel2Layout = new javax.swing.GroupLayout(tbPanel2);
        tbPanel2.setLayout(tbPanel2Layout);
        tbPanel2Layout.setHorizontalGroup(
            tbPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPaneCICL, javax.swing.GroupLayout.DEFAULT_SIZE, 1221, Short.MAX_VALUE)
        );
        tbPanel2Layout.setVerticalGroup(
            tbPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPaneCICL, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 578, Short.MAX_VALUE)
        );

        TableLayout.add(tbPanel2, "card3");

        tbCNSP.setBackground(new java.awt.Color(245, 245, 245));
        tbCNSP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "LastName", "FirstName", "M.I", "Age", "Sex", "Date of Birth", "Educational Status", "Address", "Guardian's Name", "Contact #"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbCNSP.setOpaque(false);
        tbCNSP.setSelectionBackground(new java.awt.Color(255, 255, 255));
        tbCNSP.setSelectionForeground(new java.awt.Color(255, 51, 153));
        jScrollPaneCNSP.setViewportView(tbCNSP);

        javax.swing.GroupLayout tbPanel3Layout = new javax.swing.GroupLayout(tbPanel3);
        tbPanel3.setLayout(tbPanel3Layout);
        tbPanel3Layout.setHorizontalGroup(
            tbPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPaneCNSP, javax.swing.GroupLayout.DEFAULT_SIZE, 1221, Short.MAX_VALUE)
        );
        tbPanel3Layout.setVerticalGroup(
            tbPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPaneCNSP, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 578, Short.MAX_VALUE)
        );

        TableLayout.add(tbPanel3, "card4");

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jPanel12.setLayout(new java.awt.BorderLayout());

        SearchIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/tool (1).png"))); // NOI18N
        jPanel12.add(SearchIcon, java.awt.BorderLayout.LINE_START);

        EnterSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/enter-1.png"))); // NOI18N
        EnterSearch.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        EnterSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EnterSearchMouseClicked(evt);
            }
        });
        EnterSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                EnterSearchKeyPressed(evt);
            }
        });
        jPanel12.add(EnterSearch, java.awt.BorderLayout.LINE_END);

        SearchField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SearchField.setForeground(new java.awt.Color(102, 102, 102));
        SearchField.setText("Search for Name");
        SearchField.setBorder(null);
        SearchField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchFieldMouseClicked(evt);
            }
        });
        SearchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchFieldActionPerformed(evt);
            }
        });
        jPanel12.add(SearchField, java.awt.BorderLayout.CENTER);

        SelectAll.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        SelectAll.setForeground(new java.awt.Color(0, 102, 0));
        SelectAll.setText("Select All ");
        SelectAll.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SelectAllMouseClicked(evt);
            }
        });
        SelectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectAllActionPerformed(evt);
            }
        });

        ResetSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/recycle (1).png"))); // NOI18N
        ResetSearch.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        ResetSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ResetSearchMouseClicked(evt);
            }
        });

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 0)));

        EditRecord.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        EditRecord.setForeground(new java.awt.Color(0, 102, 0));
        EditRecord.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/edit (1).png"))); // NOI18N
        EditRecord.setText("EDIT");
        EditRecord.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EditRecordMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(EditRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(EditRecord, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout ChildRecordLayout = new javax.swing.GroupLayout(ChildRecord);
        ChildRecord.setLayout(ChildRecordLayout);
        ChildRecordLayout.setHorizontalGroup(
            ChildRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ChildRecordLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(ChildRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ChildRecordLayout.createSequentialGroup()
                        .addComponent(crTab1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(crTab2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(crTab3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ResetSearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, 363, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(TableLayout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(ChildRecordLayout.createSequentialGroup()
                        .addComponent(SelectAll)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AddRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(14, 14, 14))
        );
        ChildRecordLayout.setVerticalGroup(
            ChildRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ChildRecordLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(ChildRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(crTab1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(crTab2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(crTab3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(ChildRecordLayout.createSequentialGroup()
                        .addGroup(ChildRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ResetSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TableLayout, javax.swing.GroupLayout.PREFERRED_SIZE, 578, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChildRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(AddRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SelectAll)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(24, 24, 24))
        );

        tabContents.add(ChildRecord, "card5");

        getContentPane().add(tabContents);
        tabContents.setBounds(230, 100, 1260, 740);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tab1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab1MouseClicked
        Dashboard.setVisible(true);
        ChildRecord.setVisible(false);
        ManageCase.setVisible(false);
        AddCase.setVisible(false);
        ChildInfo.setVisible(false);
        CaseCategory.setVisible(false);
        HearingSched.setVisible(false);
        User.setVisible(false);
        tab1.setBackground(new Color(0, 153, 0));
        tab2.setBackground(new Color(0, 102, 0));
        tab3.setBackground(new Color(0, 102, 0));
        tab4.setBackground(new Color(0, 102, 0));
        tab5.setBackground(new Color(0, 102, 0));


    }//GEN-LAST:event_tab1MouseClicked

    private void tab2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab2MouseClicked
        Dashboard.setVisible(false);
        ChildRecord.setVisible(true);
        ManageCase.setVisible(false);
        AddCase.setVisible(false);
        ChildInfo.setVisible(false);
        CaseCategory.setVisible(false);
        HearingSched.setVisible(false);

        User.setVisible(false);
        tab2.setBackground(new Color(0, 153, 0));
        tab1.setBackground(new Color(0, 102, 0));
        tab3.setBackground(new Color(0, 102, 0));
        tab4.setBackground(new Color(0, 102, 0));
        tab5.setBackground(new Color(0, 102, 0));
        // TODO add your handling code here:
    }//GEN-LAST:event_tab2MouseClicked

    private void tab3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab3MouseClicked
        Dashboard.setVisible(false);
        ChildRecord.setVisible(false);
        ManageCase.setVisible(true);
        User.setVisible(false);
        tab3.setBackground(new Color(0, 153, 0));
        tab2.setBackground(new Color(0, 102, 0));
        tab1.setBackground(new Color(0, 102, 0));
        tab4.setBackground(new Color(0, 102, 0));
        tab5.setBackground(new Color(0, 102, 0));

    }//GEN-LAST:event_tab3MouseClicked

    private void tab4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab4MouseClicked
        Dashboard.setVisible(false);
        ChildRecord.setVisible(false);
        AddCase.setVisible(false);
        ManageCase.setVisible(false);
        User.setVisible(true);
        tab4.setBackground(new Color(0, 153, 0));
        tab2.setBackground(new Color(0, 102, 0));
        tab3.setBackground(new Color(0, 102, 0));
        tab1.setBackground(new Color(0, 102, 0));
        tab5.setBackground(new Color(0, 102, 0));
        // TODO add your handling code here:
    }//GEN-LAST:event_tab4MouseClicked

    private void tab5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab5MouseClicked
        tab5.setBackground(new Color(0, 153, 0));
        tab2.setBackground(new Color(0, 102, 0));
        tab3.setBackground(new Color(0, 102, 0));
        tab1.setBackground(new Color(0, 102, 0));
        tab4.setBackground(new Color(0, 102, 0));
        new Login().setVisible(true);
        this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_tab5MouseClicked

    private void tab5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab5MousePressed
        tab5.setBackground(new Color(0, 153, 0));      // TODO add your handling code here:
    }//GEN-LAST:event_tab5MousePressed

    private void tab5MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab5MouseReleased
        tab5.setBackground(new Color(0, 102, 0)); // TODO add your handling code here:
    }//GEN-LAST:event_tab5MouseReleased

    private void cbSexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSexActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbSexActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed

        try {
            // ---------------------------
            // CHILD INFORMATION
            // ---------------------------
            String lastName = tfLastName.getText().trim();
            String firstName = tfFirstName.getText().trim();
            String middleInitial = tfMiddleInitial.getText().trim();
            String educ = tfEducLvl.getText().trim();
            String address = taAddress.getText().trim();
            String parentName = tfParentName.getText().trim();
            String ageStr = tfAge.getText().trim();
            String category = cbCategory.getSelectedItem() != null ? cbCategory.getSelectedItem().toString() : "";
            String contactNum = tfParentContact.getText().trim();
            String sex = cbSex.getSelectedItem() != null ? cbSex.getSelectedItem().toString() : "";
            String dob = new java.text.SimpleDateFormat("yyyy-MM-dd").format(dobChooser.getDate());

            int ageInt;
            try {
                ageInt = Integer.parseInt(ageStr);
            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(this, "⚠️ Age must be a valid number!");
                return;
            }

            // ---------------------------
            // CASE DETAILS
            // ---------------------------
            String TypesOfViolence = "";
            String perpetrators = "";
            String Crime_Committed = "";
            String ReferredBy = "";
            String DateReported = "";

            switch (category) {
                case "CAR":
                    Crime_Committed = tfCrimeCommittedCAR.getText().trim();
                    ReferredBy = tfReferredByCAR.getText().trim();
                    DateReported = new java.text.SimpleDateFormat("yyyy-MM-dd").format(DateReportedCAR.getDate());
                    break;

                case "CICL":
                    Crime_Committed = tfCrimeCommittedCICL.getText().trim();
                    ReferredBy = tfReferredByCICL.getText().trim();
                    DateReported = new java.text.SimpleDateFormat("yyyy-MM-dd").format(DateReportedCICL.getDate());
                    break;

                case "CNSP":
                    Crime_Committed = "N/A";
                    if (chbPhysicalAbuse.isSelected()) {
                        TypesOfViolence += chbPhysicalAbuse.getText() + ", ";
                    }
                    if (chbSexualAbuse.isSelected()) {
                        TypesOfViolence += chbSexualAbuse.getText() + ", ";
                    }
                    if (chbPEA.isSelected()) {
                        TypesOfViolence += chbPEA.getText() + ", ";
                    }
                    if (chbNeglect.isSelected()) {
                        TypesOfViolence += chbNeglect.getText() + ", ";
                    }

                    if (TypesOfViolence.endsWith(", ")) {
                        TypesOfViolence = TypesOfViolence.substring(0, TypesOfViolence.length() - 2);
                    }

                    perpetrators = tfPerpetrator.getText().trim();
                    ReferredBy = tfReferredByCNSP.getText().trim();
                    DateReported = new java.text.SimpleDateFormat("yyyy-MM-dd").format(DateReportedCNSP.getDate());
                    break;
            }

            // ---------------------------
            // VALIDATION
            // ---------------------------
            if (firstName.isEmpty() || lastName.isEmpty() || middleInitial.isEmpty()
                    || educ.isEmpty() || address.isEmpty() || parentName.isEmpty()
                    || ageStr.isEmpty() || contactNum.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in ALL fields!");
                return;
            }

            if (dobChooser.getDate() == null) {
                JOptionPane.showMessageDialog(this, "Please select a Date of Birth!");
                return;
            }

            if (cbSex.getSelectedItem() == null || cbCategory.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Please select Sex and Category!");
                return;
            }

            // ---------------------------
            // CREATE CHILD OBJECT
            // ---------------------------
            child Child = new child(lastName, firstName, middleInitial, ageInt, sex, dob, educ, address, parentName, contactNum);
            childList.add(Child);

            int childId = ChildDAO.insertChildAndGetId(
                    lastName, firstName, middleInitial, ageInt, sex, dob, educ, address, parentName, contactNum, category
            );

            if (childId <= 0) {
                JOptionPane.showMessageDialog(this, "Failed to add child!");
                return;
            }
            ChildRecordsLoader.loadRecords(category, null, tbCAR);
            ChildRecordsLoader.loadRecords(category, null, tbCICL);
            ChildRecordsLoader.loadRecords(category, null, tbCNSP);

            // ---------------------------
            // INSERT CASE DETAILS
            // ---------------------------
            String defaultActionTaken = "Pending";
            boolean caseInserted = false;

            switch (category) {
                case "CAR":
                case "CICL":
                    caseInserted = CaseDAO.insertCaseByCategory(
                            Crime_Committed, null, null, ReferredBy, DateReported, childId, defaultActionTaken, category
                    );
                    break;
                case "CNSP":
                    caseInserted = CaseDAO.insertCaseByCategory(
                            null, TypesOfViolence, perpetrators, ReferredBy, DateReported, childId, defaultActionTaken, category
                    );
                    break;
            }

            if (!caseInserted) {
                JOptionPane.showMessageDialog(this, "Failed to insert case details!");
                return;
            }

            // ---------------------------
            // ADD TO CATEGORY-SPECIFIC TABLE
            // ---------------------------
            DefaultTableModel model;
            switch (category) {
                case "CAR":
                    model = (DefaultTableModel) tbCAR.getModel();
                    model.addRow(new Object[]{
                        Child.getlastName(), Child.getfirstName(), Child.getmiddleInitial(),
                        Child.getage(), Child.getsex(), Child.getdob(), Child.geteducLvl(),
                        Child.getaddress(), Child.getparentName(), Child.getcontactNum()
                    });
                    break;

                case "CICL":
                    model = (DefaultTableModel) tbCICL.getModel();
                    model.addRow(new Object[]{
                        Child.getlastName(), Child.getfirstName(), Child.getmiddleInitial(),
                        Child.getage(), Child.getsex(), Child.getdob(), Child.geteducLvl(),
                        Child.getaddress(), Child.getparentName(), Child.getcontactNum()
                    });
                    break;

                case "CNSP":
                    model = (DefaultTableModel) tbCNSP.getModel();
                    model.addRow(new Object[]{
                        Child.getlastName(), Child.getfirstName(), Child.getmiddleInitial(),
                        Child.getage(), Child.getsex(), Child.getdob(), Child.geteducLvl(),
                        Child.getaddress(), Child.getparentName(), Child.getcontactNum()
                    });
                    break;
            }

            // ---------------------------
            // ADD TO tbCase GUI TABLE
            // ---------------------------
            DefaultTableModel caseModel = (DefaultTableModel) tbCase.getModel();
            String dateReportedValue = "";

            switch (category) {
                case "CAR":
                    Case carinfo = new Case(Crime_Committed, ReferredBy, DateReported);
                    childCase.add(carinfo);
                    dateReportedValue = carinfo.getDateReported();
                    break;
                case "CICL":
                    Case ciclinfo = new Case(Crime_Committed, ReferredBy, DateReported);
                    childCase.add(ciclinfo);
                    dateReportedValue = ciclinfo.getDateReported();
                    break;
                case "CNSP":
                    CNSP cnspinfo = new CNSP(TypesOfViolence, perpetrators, ReferredBy, DateReported);
                    CNSPdetails.add(cnspinfo);
                    dateReportedValue = cnspinfo.getDateReported();
                    break;
            }

            caseModel.addRow(new Object[]{
                caseModel.getRowCount() + 1, // Case No.
                Child.getlastName() + ", " + Child.getfirstName(), // Child Name
                category, // Case Category
                dateReportedValue, // Date Reported
                "Active", // Status (default)
                "Pending" // Action Taken (default)
            });

            int modelIndex = caseModel.getRowCount() - 1; // last row added
            int viewIndex = tbCase.convertRowIndexToView(modelIndex);
            if (viewIndex >= 0) {
                tbCase.setRowSelectionInterval(viewIndex, viewIndex);
            }

            JOptionPane.showMessageDialog(this, "Record added to " + category + " and Case Table");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Something went wrong: " + ex.getMessage());
        }


    }//GEN-LAST:event_btnAddActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed

// CLEAR CHILD INFORMATION
        tfFirstName.setText("");
        tfLastName.setText("");
        tfMiddleInitial.setText("");
        tfEducLvl.setText("");
        taAddress.setText("");
        tfParentName.setText("");
        tfAge.setText("");
        tfParentContact.setText("");
        dobChooser.setDate(null);
        cbSex.setSelectedIndex(0);
        cbCategory.setSelectedIndex(0);

// CLEAR CAR CASE DETAILS
        tfCrimeCommittedCAR.setText("");
        tfReferredByCAR.setText("");
        DateReportedCAR.setDate(null);

// CLEAR CICL CASE DETAILS
        tfCrimeCommittedCICL.setText("");
        tfReferredByCICL.setText("");
        DateReportedCICL.setDate(null);

// CLEAR CNSP CASE DETAILS
        chbPhysicalAbuse.setSelected(false);
        chbSexualAbuse.setSelected(false);
        chbPEA.setSelected(false);
        chbNeglect.setSelected(false);
        tfPerpetrator.setText("");
        tfReferredByCNSP.setText("");
        DateReportedCNSP.setDate(null);

    }//GEN-LAST:event_btnClearActionPerformed

    private void cbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbCategoryActionPerformed

        String category = cbCategory.getSelectedItem().toString();

        switch (category) {
            case "CAR":
                CARCaseDetails.setVisible(true);
                CICLCaseDetails.setVisible(false);
                CNSPCaseDetails.setVisible(false);
                break;
            case "CICL":
                CARCaseDetails.setVisible(false);
                CICLCaseDetails.setVisible(true);
                CNSPCaseDetails.setVisible(false);
                break;
            case "CNSP":
                CARCaseDetails.setVisible(false);
                CICLCaseDetails.setVisible(false);
                CNSPCaseDetails.setVisible(true);
                break;
        }


    }//GEN-LAST:event_cbCategoryActionPerformed

    private void tfParentContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfParentContactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfParentContactActionPerformed

    private void tfReferredByCARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfReferredByCARActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfReferredByCARActionPerformed

    private void chbPhysicalAbuseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chbPhysicalAbuseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chbPhysicalAbuseActionPerformed

    private void chbNeglectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chbNeglectActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chbNeglectActionPerformed

    private void chbPEAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chbPEAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chbPEAActionPerformed

    private void chbSexualAbuseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chbSexualAbuseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chbSexualAbuseActionPerformed

    private void AddRecordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddRecordMouseClicked
        Dashboard.setVisible(false);
        ChildRecord.setVisible(false);
        ManageCase.setVisible(false);
        AddCase.setVisible(true);
        ChildInfo.setVisible(true);
        CaseCategory.setVisible(true);
        HearingSched.setVisible(true);
        User.setVisible(false);

    }//GEN-LAST:event_AddRecordMouseClicked

    private void crTab3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_crTab3MouseClicked
        tbPanel1.setVisible(false);
        tbPanel2.setVisible(false);
        tbPanel3.setVisible(true);
        AddCase.setVisible(false);
        ChildInfo.setVisible(false);
        CaseCategory.setVisible(false);
        HearingSched.setVisible(false);
        crTab3.setBackground(new Color(0, 102, 0));
        CNSP.setForeground(new java.awt.Color(255, 255, 255));
        CICL.setForeground(new java.awt.Color(0, 102, 0));
        CAR.setForeground(new java.awt.Color(0, 102, 0));

        crTab2.setBackground(new Color(255, 255, 255));
        crTab2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 1, true));
        crTab1.setBackground(new Color(255, 255, 255));
        crTab1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 1, true));
    }//GEN-LAST:event_crTab3MouseClicked

    private void crTab2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_crTab2MouseClicked
        tbPanel1.setVisible(false);
        tbPanel2.setVisible(true);
        tbPanel3.setVisible(false);
        AddCase.setVisible(false);
        ChildInfo.setVisible(false);
        CaseCategory.setVisible(false);
        HearingSched.setVisible(false);

        CICL.setForeground(new java.awt.Color(255, 255, 255));
        CAR.setForeground(new java.awt.Color(0, 102, 0));
        CNSP.setForeground(new java.awt.Color(0, 102, 0));
        crTab1.setBackground(new Color(255, 255, 255));
        crTab2.setBackground(new Color(0, 102, 0));
        crTab1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 1, true));
        crTab3.setBackground(new Color(255, 255, 255));
        crTab3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 1, true));
    }//GEN-LAST:event_crTab2MouseClicked

    private void crTab1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_crTab1MouseClicked
        tbPanel1.setVisible(true);
        tbPanel2.setVisible(false);
        tbPanel3.setVisible(false);
        AddCase.setVisible(false);
        ChildInfo.setVisible(false);
        CaseCategory.setVisible(false);
        HearingSched.setVisible(false);
        crTab1.setBackground(new Color(0, 102, 0));
        crTab2.setBackground(new Color(255, 255, 255));
        CICL.setForeground(new java.awt.Color(0, 102, 0));
        CNSP.setForeground(new java.awt.Color(0, 102, 0));
        CAR.setForeground(new java.awt.Color(255, 255, 255));
        crTab2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 1, true));
        crTab3.setBackground(new Color(255, 255, 255));
        crTab3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 1, true));
    }//GEN-LAST:event_crTab1MouseClicked

    private void EnterSearchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_EnterSearchKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_EnterSearchKeyPressed

    private void EnterSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EnterSearchMouseClicked
        String keyword = SearchField.getText().trim();

        JTable activeTable = null;
        String category = "";

        if (tbCAR.getParent().isShowing()) {
            activeTable = tbCAR;
            category = "CAR";
        } else if (tbCICL.getParent().isShowing()) {
            activeTable = tbCICL;
            category = "CICL";
        } else if (tbCNSP.getParent().isShowing()) {
            activeTable = tbCNSP;
            category = "CNSP";
        }

        if (activeTable != null) {
            ChildRecordsLoader.loadRecords(category, keyword, activeTable);
        }
    }//GEN-LAST:event_EnterSearchMouseClicked

    private void ResetSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ResetSearchMouseClicked

        SearchField.setText("");

        JTable activeTable = null;
        String category = "";

// Determine which Card (panel) is visible
        if (tbPanel1.isVisible()) {
            activeTable = tbCAR;
            category = "CAR";
        } else if (tbPanel2.isVisible()) {
            activeTable = tbCICL;
            category = "CICL";
        } else if (tbPanel3.isVisible()) {
            activeTable = tbCNSP;
            category = "CNSP";
        } else {
            JOptionPane.showMessageDialog(this, "⚠ Unable to determine active table.");
            return;
        }

// Reload records with empty keyword to reset table
        ChildRecordsLoader.loadRecords(category, "", activeTable);


    }//GEN-LAST:event_ResetSearchMouseClicked

    private void SearchFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchFieldMouseClicked
        SearchField.selectAll();
    }//GEN-LAST:event_SearchFieldMouseClicked

    private void SearchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchFieldActionPerformed

        // Select all text when the field gains action (optional)
        SearchField.selectAll();

        // Trigger your search logic here
        String keyword = SearchField.getText().trim();

        // Determine which table is currently active (replace with your actual logic)
        JTable activeTable = null;
        String category = "";

        if (tbCAR.isShowing()) {
            activeTable = tbCAR;
            category = "CAR";
        } else if (tbCICL.isShowing()) {
            activeTable = tbCICL;
            category = "CICL";
        } else if (tbCNSP.isShowing()) {
            activeTable = tbCNSP;
            category = "CNSP";
        }

        if (activeTable != null) {
            ChildRecordsLoader.loadRecords(category, keyword, activeTable);
        }


    }//GEN-LAST:event_SearchFieldActionPerformed

    private void tfActionTakenCARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfActionTakenCARActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfActionTakenCARActionPerformed

    private void cbSettledCARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSettledCARActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbSettledCARActionPerformed

    private void cbUnsettledCARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbUnsettledCARActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbUnsettledCARActionPerformed

    private void tfActionTakenCICLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfActionTakenCICLActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfActionTakenCICLActionPerformed

    private void cbSettledCICLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSettledCICLActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbSettledCICLActionPerformed

    private void cbUnsettledCICLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbUnsettledCICLActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbUnsettledCICLActionPerformed

    private void tfActionTakenCNSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfActionTakenCNSPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfActionTakenCNSPActionPerformed

    private void cbSettledCNSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSettledCNSPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbSettledCNSPActionPerformed

    private void cbUnsettledCNSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbUnsettledCNSPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbUnsettledCNSPActionPerformed

    private void tbCaseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbCaseMouseClicked

        try {
            User.setVisible(false);
            int selectedRow = tbCase.getSelectedRow();
            if (selectedRow < 0) {
                return; // no row selected
            }
            int modelRow = tbCase.convertRowIndexToModel(selectedRow);

            // Get category from column 2
            String category = tbCase.getModel().getValueAt(modelRow, 2).toString();

            // Hide all cards first
            for (Component card : MainCardPanel.getComponents()) {
                card.setVisible(false);
            }

            // Get child name from column 1 (Child Name)
            String childName = tbCase.getModel().getValueAt(modelRow, 1).toString();
            String[] nameParts = childName.split(",\\s*");
            String lastName = nameParts[0];
            String firstName = nameParts.length > 1 ? nameParts[1] : "";

            // Query database to fetch childID
            int childID = -1;
            try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(
                    "SELECT childID FROM child_tb WHERE Last_name = ? AND First_name = ?")) {
                pst.setString(1, lastName);
                pst.setString(2, firstName);
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    childID = rs.getInt("childID");
                } else {
                    JOptionPane.showMessageDialog(this, "Child not found in database!");
                    return;
                }
            }

            // Query database to fetch categoryID
            int categoryID = -1;
            try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(
                    "SELECT categoryID FROM category_tb WHERE categoryName = ?")) {
                pst.setString(1, category);
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    categoryID = rs.getInt("categoryID");
                } else {
                    JOptionPane.showMessageDialog(this, "Category not found in database!");
                    return;
                }
            }

            // Fetch case details based on category
            switch (category) {
                case "CAR":
                    PopUpPaneCAR.setVisible(true);
                    User.setVisible(false);
                    try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(
                            "SELECT Committed_Crime, ReferredBy, Case_Status, ActionTaken FROM casedetailscar_tb WHERE childID = ? AND categoryID = ?")) {
                        pst.setInt(1, childID);
                        pst.setInt(2, categoryID);
                        ResultSet rs = pst.executeQuery();
                        if (rs.next()) {
                            NameCAR.setText(lastName + ", " + firstName);
                            NameCAR.putClientProperty("ChildID", childID);
                            NameCAR.putClientProperty("categoryID", categoryID);
                            CommittedCAR.setText(rs.getString("Committed_Crime"));
                            RefCAR.setText(rs.getString("ReferredBy"));
                            tfActionTakenCAR.setText(rs.getString("ActionTaken"));
                        }
                    }
                    break;

                case "CICL":
                    PopUpPaneCICL.setVisible(true);
                    User.setVisible(false);
                    try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(
                            "SELECT Committed_Crime, ReferredBy, Case_Status, ActionTaken FROM casedetailscicl_tb WHERE childID = ? AND categoryID = ?")) {
                        pst.setInt(1, childID);
                        pst.setInt(2, categoryID);
                        ResultSet rs = pst.executeQuery();
                        if (rs.next()) {
                            NameCICL.setText(lastName + ", " + firstName);
                            NameCICL.putClientProperty("ChildID", childID);
                            NameCICL.putClientProperty("categoryID", categoryID);
                            CommittedCICL.setText(rs.getString("Committed_Crime"));
                            RefCICL.setText(rs.getString("ReferredBy"));
                            tfActionTakenCICL.setText(rs.getString("ActionTaken"));
                        }
                    }
                    break;

                case "CNSP":
                    PopUpPaneCNSP.setVisible(true);
                    User.setVisible(false);
                    try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(
                            "SELECT Perpetrator, TypeOfViolence, ReferredBy, Case_Status, ActionTaken FROM casedetailscnsp_tb WHERE childID = ? AND categoryID = ?")) {
                        pst.setInt(1, childID);
                        pst.setInt(2, categoryID);
                        ResultSet rs = pst.executeQuery();
                        if (rs.next()) {
                            NameCNSP.setText(lastName + ", " + firstName);
                            NameCNSP.putClientProperty("ChildID", childID);
                            NameCNSP.putClientProperty("categoryID", categoryID);
                            perpetrator.setText(rs.getString("Perpetrator"));
                            TypeOfViolence.setText(rs.getString("TypeOfViolence"));
                            RefCNSP.setText(rs.getString("ReferredBy"));
                            tfActionTakenCNSP.setText(rs.getString("ActionTaken"));
                            perpetrator.putClientProperty("ChildID", childID);
                            perpetrator.putClientProperty("categoryID", categoryID);
                        }
                    }
                    break;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Something went wrong: " + ex.getMessage());
        }

    }//GEN-LAST:event_tbCaseMouseClicked

    private void SelectAllMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SelectAllMouseClicked
        boolean select = SelectAll.isSelected(); // true if checked
        JTable currentTable = null;

        // Determine which table is visible
        if (tbPanel1.isShowing()) {
            currentTable = tbCAR;
        } else if (tbPanel2.isShowing()) {
            currentTable = tbCICL;
        } else if (tbPanel3.isShowing()) {
            currentTable = tbCNSP;
        }

        if (currentTable != null) {
            int rowCount = currentTable.getRowCount();
            if (select) {
                // Select all rows
                currentTable.setRowSelectionInterval(0, rowCount - 1);
            } else {
                // Clear selection
                currentTable.clearSelection();
            }
        }
    }//GEN-LAST:event_SelectAllMouseClicked

    private void SelectAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectAllActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelectAllActionPerformed

    private void EditRecordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EditRecordMouseClicked
        int selectedRow = -1;

        // Determine which table is currently active & has a selected row
        if (tbCAR.isShowing() && tbCAR.getSelectedRow() != -1) {
            selectedRow = tbCAR.getSelectedRow();
        } else if (tbCICL.isShowing() && tbCICL.getSelectedRow() != -1) {
            selectedRow = tbCICL.getSelectedRow();
        } else if (tbCNSP.isShowing() && tbCNSP.getSelectedRow() != -1) {
            selectedRow = tbCNSP.getSelectedRow();
        }

        if (selectedRow == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please select a row to edit first.");
            return;
        }


    }//GEN-LAST:event_EditRecordMouseClicked

    private void btnCARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCARActionPerformed
        // 1️⃣ Get hidden IDs from the popup (set these when opening the popup)
        Integer childID = (Integer) NameCAR.getClientProperty("ChildID");
        Integer categoryID = (Integer) NameCAR.getClientProperty("categoryID");

        if (childID == null || categoryID == null) {
            JOptionPane.showMessageDialog(this, "Error: ChildID or CategoryID missing.");
            return;
        }

// 2️⃣ Get user input
        boolean isSettled = cbSettledCAR.isSelected();
        boolean isUnsettled = cbUnsettledCAR.isSelected();
        String actionTaken = tfActionTakenCAR.getText().trim();

// Determine status
        String status = "Active"; // default
        if (isSettled) {
            status = "Settled";
        } else if (isUnsettled) {
            status = "Unsettled";
        }

// 3️⃣ Update database
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE casedetailscar_tb SET Case_Status=?, ActionTaken=? WHERE ChildID=? AND categoryID=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, status);
            pst.setString(2, actionTaken);
            pst.setInt(3, childID);
            pst.setInt(4, categoryID);

            int updated = pst.executeUpdate();
            if (updated > 0) {
                JOptionPane.showMessageDialog(this, "CAR record updated successfully!");

                // 4️⃣ Update tbCase GUI table
                DefaultTableModel model = (DefaultTableModel) tbCase.getModel();
                for (int i = 0; i < model.getRowCount(); i++) {
                    String childName = model.getValueAt(i, 1).toString(); // "Last, First"
                    if (childName.equals(NameCAR.getText()) && model.getValueAt(i, 2).toString().equals("CAR")) {
                        model.setValueAt(status, i, 4);      // Status column
                        model.setValueAt(actionTaken, i, 5); // Action Taken column
                        break;
                    }
                }

            } else {
                JOptionPane.showMessageDialog(this, "No record was updated.");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating CAR record: " + ex.getMessage());
        }
        refreshCounters();
    }//GEN-LAST:event_btnCARActionPerformed

    private void btnCICLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCICLActionPerformed
        // 1️⃣ Get hidden IDs from the popup
        Integer childID = (Integer) NameCICL.getClientProperty("ChildID");
        Integer categoryID = (Integer) NameCICL.getClientProperty("categoryID");

        if (childID == null || categoryID == null) {
            JOptionPane.showMessageDialog(this, "Error: ChildID or CategoryID missing.");
            return;
        }

// 2️⃣ Get user input
        boolean isSettled = cbSettledCICL.isSelected();
        boolean isUnsettled = cbUnsettledCICL.isSelected();
        String actionTaken = tfActionTakenCICL.getText().trim();

// Determine status
        String status = "Active"; // default
        if (isSettled) {
            status = "Settled";
        } else if (isUnsettled) {
            status = "Unsettled";
        }

// 3️⃣ Update database
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE casedetailscicl_tb SET Case_Status=?, ActionTaken=? WHERE ChildID=? AND categoryID=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, status);
            pst.setString(2, actionTaken);
            pst.setInt(3, childID);
            pst.setInt(4, categoryID);

            int updated = pst.executeUpdate();
            if (updated > 0) {
                JOptionPane.showMessageDialog(this, "CICL record updated successfully!");

                // 4️⃣ Update tbCase GUI table
                DefaultTableModel model = (DefaultTableModel) tbCase.getModel();
                for (int i = 0; i < model.getRowCount(); i++) {
                    String childName = model.getValueAt(i, 1).toString(); // "Last, First"
                    if (childName.equals(NameCICL.getText()) && model.getValueAt(i, 2).toString().equals("CICL")) {
                        model.setValueAt(status, i, 4);      // Status column
                        model.setValueAt(actionTaken, i, 5); // Action Taken column
                        break;
                    }
                }

            } else {
                JOptionPane.showMessageDialog(this, "No record was updated.");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating CICL record: " + ex.getMessage());
        }
        refreshCounters();
    }//GEN-LAST:event_btnCICLActionPerformed

    private void btnCNSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCNSPActionPerformed
        // 1️⃣ Get hidden IDs from the popup
        Integer childID = (Integer) perpetrator.getClientProperty("ChildID");
        Integer categoryID = (Integer) perpetrator.getClientProperty("categoryID");

        if (childID == null || categoryID == null) {
            JOptionPane.showMessageDialog(this, "Error: ChildID or CategoryID missing.");
            return;
        }

// 2️⃣ Get user input
        boolean isSettled = cbSettledCNSP.isSelected();
        boolean isUnsettled = cbUnsettledCNSP.isSelected();
        String actionTaken = tfActionTakenCNSP.getText().trim();

// Determine status
        String status = "Active"; // default
        if (isSettled) {
            status = "Settled";
        } else if (isUnsettled) {
            status = "Unsettled";
        }

// 3️⃣ Update database
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE casedetailscnsp_tb SET Case_Status=?, ActionTaken=? WHERE ChildID=? AND categoryID=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, status);
            pst.setString(2, actionTaken);
            pst.setInt(3, childID);
            pst.setInt(4, categoryID);

            int updated = pst.executeUpdate();
            if (updated > 0) {
                JOptionPane.showMessageDialog(this, "CNSP record updated successfully!");

                // 4️⃣ Update tbCase GUI table
                DefaultTableModel model = (DefaultTableModel) tbCase.getModel();
                String childName = NameCNSP.getText();
                for (int i = 0; i < model.getRowCount(); i++) {
                    String rowChildName = model.getValueAt(i, 1).toString(); // "Last, First"
                    if (rowChildName.equals(childName) && model.getValueAt(i, 2).toString().equals("CNSP")) {
                        model.setValueAt(status, i, 4);      // Status column
                        model.setValueAt(actionTaken, i, 5); // Action Taken column
                        break;
                    }
                }

            } else {
                JOptionPane.showMessageDialog(this, "No record was updated.");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating CNSP record: " + ex.getMessage());
        }
        refreshCounters();
    }//GEN-LAST:event_btnCNSPActionPerformed

    private void tbCaseSelectAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbCaseSelectAllActionPerformed
        if (tbCaseSelectAll.isSelected()) {
            tbCase.selectAll();
        } else {
            tbCase.clearSelection();
        }
    }//GEN-LAST:event_tbCaseSelectAllActionPerformed

    private void ArchiveRecord1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ArchiveRecord1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ArchiveRecord1MouseClicked

    private void ArchiveRecord1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ArchiveRecord1MousePressed
        ArchiveRecord1.setBackground(new Color(0, 102, 0));
        ArchiveRecords.setForeground(new java.awt.Color(255, 255, 255));
    }//GEN-LAST:event_ArchiveRecord1MousePressed

    private void ArchiveRecord1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ArchiveRecord1MouseReleased
        ArchiveRecord1.setBackground(new Color(255, 255, 255));
        ArchiveRecords.setForeground(new java.awt.Color(0, 102, 0));
    }//GEN-LAST:event_ArchiveRecord1MouseReleased

    private void ArchiveRecord1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ArchiveRecord1MouseEntered
        ArchiveRecord1.setBackground(new Color(153, 255, 153));
        ArchiveRecords.setForeground(new java.awt.Color(0, 102, 0));
    }//GEN-LAST:event_ArchiveRecord1MouseEntered

    private void ArchiveRecord1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ArchiveRecord1MouseExited
        ArchiveRecord1.setBackground(new Color(255, 255, 255));
        ArchiveRecords.setForeground(new java.awt.Color(0, 102, 0));
    }//GEN-LAST:event_ArchiveRecord1MouseExited

    private void AddRecordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddRecordMouseEntered
        AddRecord.setBackground(new Color(0, 153, 0));

    }//GEN-LAST:event_AddRecordMouseEntered

    private void AddRecordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddRecordMouseExited
        AddRecord.setBackground(new Color(0, 102, 0));

    }//GEN-LAST:event_AddRecordMouseExited

    private void AddRecordMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddRecordMousePressed
        AddRecord.setBackground(new Color(0, 204, 0));
    }//GEN-LAST:event_AddRecordMousePressed

    private void AddRecordMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddRecordMouseReleased
        AddRecord.setBackground(new Color(0, 102, 0));
    }//GEN-LAST:event_AddRecordMouseReleased

    private void ArchiveRecordsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ArchiveRecordsMouseClicked
        
    }//GEN-LAST:event_ArchiveRecordsMouseClicked

    private void btnArchivedMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnArchivedMouseClicked
        // Create an instance of Archive frame
        PanelArchived.setVisible(true);
        PanelRecentRecords.setVisible(false);
        btnRetrieve.setVisible(true);


    }//GEN-LAST:event_btnArchivedMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        PanelArchived.setVisible(false);
        PanelRecentRecords.setVisible(true);
        btnRetrieve.setVisible(false);

    }//GEN-LAST:event_jButton1MouseClicked

    private void btnRetrieveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetrieveActionPerformed
        DefaultTableModel model = (DefaultTableModel) ArchivedRecords.getModel();

        try (Connection conn = DBConnection.getConnection()) {

            for (int i = 0; i < model.getRowCount(); i++) {
                Boolean isSelected = (Boolean) model.getValueAt(i, 0); // checkbox in archive table

                if (isSelected != null && isSelected) {
                    String lastName = model.getValueAt(i, 0).toString();
                    String firstName = model.getValueAt(i, 1).toString();
                    String category = model.getValueAt(i, 2).toString();

                    // Get the child's ID from archive
                    PreparedStatement getChild = conn.prepareStatement(
                            "SELECT ChildID FROM child_tb_archive WHERE Last_Name=? AND First_Name=?"
                    );
                    getChild.setString(1, lastName);
                    getChild.setString(2, firstName);
                    ResultSet rs = getChild.executeQuery();

                    if (rs.next()) {
                        int childID = rs.getInt("ChildID");

                        // Move child record back
                        conn.prepareStatement(
                                "INSERT INTO child_tb SELECT * FROM child_tb_archive WHERE ChildID=" + childID
                        ).executeUpdate();
                        conn.prepareStatement(
                                "DELETE FROM child_tb_archive WHERE ChildID=" + childID
                        ).executeUpdate();

                        // Move corresponding case
                        String caseTable = "", archiveTable = "";

                        if (category.equalsIgnoreCase("CAR")) {
                            caseTable = "casedetailscar_tb";
                            archiveTable = "casedetailscar_tb_archive";
                        } else if (category.equalsIgnoreCase("CICL")) {
                            caseTable = "casedetailscicl_tb";
                            archiveTable = "casedetailscicl_tb_archive";
                        } else if (category.equalsIgnoreCase("CNSP")) {
                            caseTable = "casedetailscnsp_tb";
                            archiveTable = "casedetailscnsp_tb_archive";
                        }

                        conn.prepareStatement(
                                "INSERT INTO " + caseTable + " SELECT * FROM " + archiveTable + " WHERE ChildID=" + childID
                        ).executeUpdate();
                        conn.prepareStatement(
                                "DELETE FROM " + archiveTable + " WHERE ChildID=" + childID
                        ).executeUpdate();
                    }
                }
            }

            JOptionPane.showMessageDialog(this, "Records restored successfully!");
            model.setRowCount(0); // clear archive table

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error restoring: " + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnRetrieveActionPerformed

    private void SaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveButtonActionPerformed
        String newUsername = Username.getText().trim();
        String newPassword = Password.getText().trim();

        if (newUsername.isEmpty() || newPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in both username and password.", "Missing Fields", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Call the DAO method
        UserDAO.updateCredentials(newUsername, newPassword);

    }//GEN-LAST:event_SaveButtonActionPerformed

    private void UsernameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UsernameMouseClicked
        Username.selectAll();        // TODO add your handling code here:
    }//GEN-LAST:event_UsernameMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
 /* java.awt.EventQueue.invokeLater(() -> new DashBoard().setVisible(true));*/
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel AddCase;
    private javax.swing.JLabel AddLabel;
    private javax.swing.JPanel AddRecord;
    private javax.swing.JPanel ArchiveRecord1;
    private javax.swing.JLabel ArchiveRecords;
    private javax.swing.JTable ArchivedRecords;
    private javax.swing.JLabel BrgyName;
    private javax.swing.JLabel CAR;
    private javax.swing.JPanel CARCaseDetails;
    private javax.swing.JLabel CICL;
    private javax.swing.JPanel CICLCaseDetails;
    private javax.swing.JLabel CNSP;
    private javax.swing.JPanel CNSPCaseDetails;
    private javax.swing.JPanel CaseCategory;
    private javax.swing.JPanel CaseDetailsLayout4;
    private javax.swing.JPanel ChildInfo;
    private javax.swing.JPanel ChildRecord;
    private javax.swing.JLabel CommittedCAR;
    private javax.swing.JLabel CommittedCICL;
    private javax.swing.JPanel Dashboard;
    private com.toedter.calendar.JDateChooser DateReportedCAR;
    private com.toedter.calendar.JDateChooser DateReportedCICL;
    private com.toedter.calendar.JDateChooser DateReportedCNSP;
    private javax.swing.JLabel EditRecord;
    private javax.swing.JLabel EnterSearch;
    private javax.swing.JPanel HearingSched;
    private javax.swing.JLabel JLabel;
    private javax.swing.JLabel Logo;
    private javax.swing.JPanel MainCardPanel;
    private javax.swing.JPanel ManageCase;
    private javax.swing.JLabel MoreInfoSettled;
    private javax.swing.JLabel MoreInfoUnsettled;
    private javax.swing.JLabel NameCAR;
    private javax.swing.JLabel NameCICL;
    private javax.swing.JLabel NameCNSP;
    private javax.swing.JPanel PanelArchived;
    private javax.swing.JPanel PanelRecentRecords;
    private javax.swing.JPasswordField Password;
    private javax.swing.JPanel PopUpPaneCAR;
    private javax.swing.JPanel PopUpPaneCICL;
    private javax.swing.JPanel PopUpPaneCNSP;
    private javax.swing.JTable RecentRecord;
    private javax.swing.JLabel RefCAR;
    private javax.swing.JLabel RefCICL;
    private javax.swing.JLabel RefCNSP;
    private javax.swing.JLabel ResetSearch;
    private javax.swing.JButton SaveButton;
    private javax.swing.JScrollPane ScrollPaneArchived;
    private javax.swing.JScrollPane ScrollPaneRecent;
    private javax.swing.JTextField SearchField;
    private javax.swing.JLabel SearchIcon;
    private javax.swing.JCheckBox SelectAll;
    private javax.swing.JLabel SettledCounter;
    private javax.swing.JLabel SubLabelBCPC;
    private javax.swing.JPanel TITLEHOLDER;
    private javax.swing.JPanel TableLayout;
    private javax.swing.JLabel TypeOfViolence;
    private javax.swing.JLabel UnsettledCounter;
    private javax.swing.JPanel User;
    private javax.swing.JTextField Username;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnArchived;
    private javax.swing.JButton btnCAR;
    private javax.swing.JButton btnCICL;
    private javax.swing.JButton btnCNSP;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnRetrieve;
    private javax.swing.JComboBox<String> cbCategory;
    private javax.swing.JCheckBox cbSettledCAR;
    private javax.swing.JCheckBox cbSettledCICL;
    private javax.swing.JCheckBox cbSettledCNSP;
    private javax.swing.JComboBox<String> cbSex;
    private javax.swing.JCheckBox cbUnsettledCAR;
    private javax.swing.JCheckBox cbUnsettledCICL;
    private javax.swing.JCheckBox cbUnsettledCNSP;
    private javax.swing.JCheckBox chbNeglect;
    private javax.swing.JCheckBox chbPEA;
    private javax.swing.JCheckBox chbPhysicalAbuse;
    private javax.swing.JCheckBox chbSexualAbuse;
    private javax.swing.JPanel crTab1;
    private javax.swing.JPanel crTab2;
    private javax.swing.JPanel crTab3;
    private javax.swing.JSpinner dateTimeSpinner;
    private com.toedter.calendar.JDateChooser dobChooser;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPaneCAR;
    private javax.swing.JScrollPane jScrollPaneCICL;
    private javax.swing.JScrollPane jScrollPaneCNSP;
    private javax.swing.JScrollPane jScrollPaneCase;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JLabel lblDateTime;
    private javax.swing.JPanel menuHolder;
    private javax.swing.JLabel perpetrator;
    private javax.swing.JTextArea taAddress;
    private javax.swing.JPanel tab1;
    private javax.swing.JPanel tab2;
    private javax.swing.JPanel tab3;
    private javax.swing.JPanel tab4;
    private javax.swing.JPanel tab5;
    private javax.swing.JPanel tabContents;
    private javax.swing.JTable tbCAR;
    private javax.swing.JTable tbCICL;
    private javax.swing.JTable tbCNSP;
    private javax.swing.JTable tbCase;
    private javax.swing.JLabel tbCaseEnter;
    private javax.swing.JLabel tbCaseReset;
    private javax.swing.JTextField tbCaseSearchField;
    private javax.swing.JCheckBox tbCaseSelectAll;
    private javax.swing.JPanel tbPanel1;
    private javax.swing.JPanel tbPanel2;
    private javax.swing.JPanel tbPanel3;
    private javax.swing.JTextField tfActionTakenCAR;
    private javax.swing.JTextField tfActionTakenCICL;
    private javax.swing.JTextField tfActionTakenCNSP;
    private javax.swing.JTextField tfAge;
    private javax.swing.JTextField tfCrimeCommittedCAR;
    private javax.swing.JTextField tfCrimeCommittedCICL;
    private javax.swing.JTextField tfEducLvl;
    private javax.swing.JTextField tfFirstName;
    private javax.swing.JTextField tfLastName;
    private javax.swing.JTextField tfMiddleInitial;
    private javax.swing.JTextField tfParentContact;
    private javax.swing.JTextField tfParentName;
    private javax.swing.JTextField tfPerpetrator;
    private javax.swing.JTextField tfReferredByCAR;
    private javax.swing.JTextField tfReferredByCICL;
    private javax.swing.JTextField tfReferredByCNSP;
    // End of variables declaration//GEN-END:variables

}
