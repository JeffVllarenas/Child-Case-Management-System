package childcasemanagementsystem;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class CaseTableLoader {

    // 🟢 Load Active Cases into tbCase
    public static void loadActiveCases(JTable tbCase) {
        DefaultTableModel model = (DefaultTableModel) tbCase.getModel();
        model.setRowCount(0); // clear table

        try (Connection conn = DBConnection.getConnection()) {
            String sql = """
                SELECT c.Last_Name, c.First_Name, d.Category, d.DateReported, d.Case_Status, d.ActionTaken
                FROM child_tb c
                JOIN (
                    SELECT ChildID, 'CAR' AS Category, DateReported, Case_Status, ActionTaken FROM casedetailscar_tb
                    UNION ALL
                    SELECT ChildID, 'CICL' AS Category, DateReported, Case_Status, ActionTaken FROM casedetailscicl_tb
                    UNION ALL
                    SELECT ChildID, 'CNSP' AS Category, DateReported, Case_Status, ActionTaken FROM casedetailscnsp_tb
                ) d ON c.ChildID = d.ChildID
                ORDER BY d.DateReported DESC
            """;
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    false,
                    rs.getString("Last_Name"),
                    rs.getString("First_Name"),
                    rs.getString("Category"),
                    rs.getString("DateReported"),
                    rs.getString("Case_Status"),
                    rs.getString("ActionTaken")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading active cases: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // 🔴 Load Archived Cases into tbArchived
    public static void loadArchivedCases(JTable tbArchived) {
        DefaultTableModel model = (DefaultTableModel) tbArchived.getModel();
        model.setRowCount(0);

        try (Connection conn = DBConnection.getConnection()) {
            String sql = """
                SELECT c.Last_Name, c.First_Name, d.Category, d.DateReported, d.ArchiveDate
                FROM child_tb_archive c
                JOIN (
                    SELECT ChildID, 'CAR' AS Category, DateReported, ArchiveDate FROM casedetailscar_tb_archive
                    UNION ALL
                    SELECT ChildID, 'CICL' AS Category, DateReported, ArchiveDate FROM casedetailscicl_tb_archive
                    UNION ALL
                    SELECT ChildID, 'CNSP' AS Category, DateReported, ArchiveDate FROM casedetailscnsp_tb_archive
                ) d ON c.ChildID = d.ChildID
                ORDER BY d.ArchiveDate DESC
            """;
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    false,
                    rs.getString("LastName"),
                    rs.getString("FirstName"),
                    rs.getString("Category"),
                    rs.getString("DateReported")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading archived cases: " + e.getMessage());
            e.printStackTrace();
        }
    }
}