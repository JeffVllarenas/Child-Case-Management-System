package childcasemanagementsystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChildInfoLoader {

    public static void loadAll(JTable tbCAR, JTable tbCICL, JTable tbCNSP) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT child_tb.Last_name, child_tb.First_name, child_tb.middleInitial, " +
                     "child_tb.ChildAge, child_tb.Sex, child_tb.DateOfBirth, child_tb.EducLvlOrStatus, " +
                     "child_tb.Address, child_tb.Parent_name, child_tb.ParentContactNum, " +
                     "category_tb.categoryName " +
                     "FROM child_tb " +
                     "LEFT JOIN category_tb ON child_tb.categoryID = category_tb.categoryID";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            DefaultTableModel carModel = (DefaultTableModel) tbCAR.getModel();
            DefaultTableModel ciclModel = (DefaultTableModel) tbCICL.getModel();
            DefaultTableModel cnspModel = (DefaultTableModel) tbCNSP.getModel();

            // Clear existing rows
            carModel.setRowCount(0);
            ciclModel.setRowCount(0);
            cnspModel.setRowCount(0);

            while (rs.next()) {
                String lastName = rs.getString("Last_name");
                String firstName = rs.getString("First_name");
                String middleInitial = rs.getString("middleInitial");
                int age = rs.getInt("ChildAge");
                String sex = rs.getString("Sex");
                String dob = rs.getString("DateOfBirth");
                String educ = rs.getString("EducLvlOrStatus");
                String address = rs.getString("Address");
                String parentName = rs.getString("Parent_name");
                String contactNum = rs.getString("ParentContactNum");
                String category = rs.getString("categoryName");

                switch (category) {
                    case "CAR":
                        carModel.addRow(new Object[]{lastName, firstName, middleInitial, age, sex, dob, educ, address, parentName, contactNum});
                        break;
                    case "CICL":
                        ciclModel.addRow(new Object[]{lastName, firstName, middleInitial, age, sex, dob, educ, address, parentName, contactNum});
                        break;
                    case "CNSP":
                        cnspModel.addRow(new Object[]{lastName, firstName, middleInitial, age, sex, dob, educ, address, parentName, contactNum});
                        break;
                }
            }

            // ✅ Sort each table by Last Name (column 0) ascending A–Z
            sortTableByLastName(tbCAR);
            sortTableByLastName(tbCICL);
            sortTableByLastName(tbCNSP);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading child data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void sortTableByLastName(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        List<RowSorter.SortKey> sortKeys = new ArrayList<>();
        sortKeys.add(new RowSorter.SortKey(0, SortOrder.ASCENDING)); // 0 = Last Name column
        sorter.setSortKeys(sortKeys);
        sorter.sort();
    }
}
