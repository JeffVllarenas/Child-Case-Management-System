package childcasemanagementsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class CaseLoader {

    public static void loadAllCases(JTable tbCase) {
        DefaultTableModel model = (DefaultTableModel) tbCase.getModel();
        model.setRowCount(0); // ✅ Clear existing rows

        int caseNoCounter = 1;

        try (Connection conn = DBConnection.getConnection()) {

            // =============================
            // CAR CASES
            // =============================
            String sqlCar = "SELECT child_tb.Last_name, child_tb.First_name, category_tb.categoryName, casedetailscar_tb.DateReported, casedetailscar_tb.Case_Status, casedetailscar_tb.ActionTaken "
                    + "FROM casedetailscar_tb "
                    + "JOIN child_tb ON casedetailscar_tb.ChildID = child_tb.ChildID "
                    + "JOIN category_tb ON casedetailscar_tb.categoryID = category_tb.categoryID";
            try (PreparedStatement pst = conn.prepareStatement(sqlCar);
                 ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {
                    String fullName = rs.getString("Last_name") + ", " + rs.getString("First_name");
                    String category = rs.getString("categoryName");
                    String dateReported = rs.getString("DateReported");
                    String status = rs.getString("Case_Status");
                    String actionTaken = rs.getString("ActionTaken");

                    model.addRow(new Object[]{
                            caseNoCounter++,
                            fullName,
                            category,
                            dateReported,
                            status,
                            actionTaken
                    });
                }
            }

            // =============================
            // CICL CASES
            // =============================
            String sqlCicl = "SELECT child_tb.Last_name, child_tb.First_name, category_tb.categoryName, casedetailscicl_tb.DateReported, casedetailscicl_tb.Case_Status, casedetailscicl_tb.ActionTaken "
                    + "FROM casedetailscicl_tb "
                    + "JOIN child_tb ON casedetailscicl_tb.ChildID = child_tb.ChildID "
                    + "JOIN category_tb  ON casedetailscicl_tb.categoryID = category_tb.categoryID";
            try (PreparedStatement pst = conn.prepareStatement(sqlCicl);
                 ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {
                    String fullName = rs.getString("Last_name") + ", " + rs.getString("First_name");
                    String category = rs.getString("categoryName");
                    String dateReported = rs.getString("DateReported");
                    String status = rs.getString("Case_Status");
                    String actionTaken = rs.getString("ActionTaken");

                    model.addRow(new Object[]{
                            caseNoCounter++,
                            fullName,
                            category,
                            dateReported,
                            status,
                            actionTaken
                    });
                }
            }

            // =============================
            // CNSP CASES
            // =============================
            String sqlCnsp = "SELECT child_tb.Last_name, child_tb.First_name, category_tb.categoryName, casedetailscnsp_tb.DateReported, casedetailscnsp_tb.Case_Status, casedetailscnsp_tb.ActionTaken "
                    + "FROM casedetailscnsp_tb "
                    + "JOIN child_tb ON casedetailscnsp_tb.ChildID = child_tb.ChildID "
                    + "JOIN category_tb  ON casedetailscnsp_tb.categoryID = category_tb.categoryID";
            try (PreparedStatement pst = conn.prepareStatement(sqlCnsp);
                 ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {
                    String fullName = rs.getString("Last_name") + ", " + rs.getString("First_name");
                    String category = rs.getString("categoryName");
                    String dateReported = rs.getString("DateReported");
                    String status = rs.getString("Case_Status");
                    String actionTaken = rs.getString("ActionTaken");

                    model.addRow(new Object[]{
                            caseNoCounter++,
                            fullName,
                            category,
                            dateReported,
                            status,
                            actionTaken
                    });
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(null, "❌ Failed to load cases: " + e.getMessage());
        }
    }
}

