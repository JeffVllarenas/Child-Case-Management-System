

package childcasemanagementsystem;


public class ChildCaseManagementSystem {


    public static void main(String[] args) {
        
        java.awt.EventQueue.invokeLater(() -> new Login().setVisible(true));
        
    }
    

}
        

