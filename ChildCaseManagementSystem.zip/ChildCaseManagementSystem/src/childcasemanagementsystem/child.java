package childcasemanagementsystem;


public class child {
    private String lastName; 
    private String firstName;
    private String middleInitial;
    private int age;
    private String sex;
    private String dob;
    private String educLvl;
    private String address;
    private String parentName;
    private String contactNum;
    
    
    child (String lastName, String firstName, String middleInitial, int age, String sex, String dob, String educLvl, String address, String parentName, String contactNum){
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleInitial = middleInitial;
        this.age = age;
        this.sex = sex;
        this.dob = dob;
        this.educLvl = educLvl;
        this.address = address;
        this.parentName = parentName;
        this.contactNum = contactNum;
        
        
    }

    
        
    
    
     String getlastName (){ return lastName;}
     String getfirstName () {return firstName;}
     String getmiddleInitial () {return middleInitial;}
     int getage () {return age;}
     String getsex () {return sex;}
     String getdob () {return dob;}
     String geteducLvl () {return educLvl;}
     String getaddress () {return address;}
     String getparentName () {return parentName;}
     String getcontactNum () {return contactNum;}
      
    
    
}
  
