
package childcasemanagementsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Counter {

    private int settledCount;
    private int unsettledCount;

    public Counter() {
        this.settledCount = 0;
        this.unsettledCount = 0;
    }

    // ✅ Method to update counts from database
    public void refresh() {
        settledCount = 0;
        unsettledCount = 0;

        // Array of all case tables
        String[] tables = {"casedetailscar_tb", "casedetailscicl_tb", "casedetailscnsp_tb"};

        try (Connection conn = DBConnection.getConnection()) {
            for (String table : tables) {
                String sql = "SELECT Case_Status, COUNT(*) AS cnt FROM " + table + " GROUP BY Case_Status";
                PreparedStatement pst = conn.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();

                while (rs.next()) {
                    String status = rs.getString("Case_Status");
                    int count = rs.getInt("cnt");
                    if (status.equalsIgnoreCase("Settled")) settledCount += count;
                    if (status.equalsIgnoreCase("Unsettled")) unsettledCount += count;
                }

                rs.close();
                pst.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ✅ Getters
    public int getSettledCount() {
        return settledCount;
    }

    public int getUnsettledCount() {
        return unsettledCount;
    }
}
