package childcasemanagementsystem;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class TableEmptyMessage {

    public static void attach(JTable table, JScrollPane scrollPane, String message) {
        // Create label
        JLabel emptyLabel = new JLabel(message, SwingConstants.CENTER);
        emptyLabel.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        emptyLabel.setForeground(Color.GRAY);
        emptyLabel.setOpaque(true);
        emptyLabel.setBackground(Color.WHITE);

        // Set scroll pane background
        scrollPane.getViewport().setBackground(Color.WHITE);

        // Initial state check
        if (table.getRowCount() == 0) {
            scrollPane.setViewportView(emptyLabel);
        }

        // Listen for data changes
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.addTableModelListener((TableModelEvent e) -> {
            if (model.getRowCount() == 0) {
                scrollPane.setViewportView(emptyLabel);
            } else {
                scrollPane.setViewportView(table);
            }
        });
    }
}
