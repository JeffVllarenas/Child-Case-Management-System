package childcasemanagementsystem;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

public class CaseTableDesign {

    // ✅ For tbCase only
    public static void customize(JTable table) {
        // Table font and row height
        table.setFont(new java.awt.Font("Segoe UI", 0, 18));
        table.setRowHeight(50);
        table.setShowGrid(false);
        table.setGridColor(Color.WHITE);
        table.setIntercellSpacing(new java.awt.Dimension(1, 1));

        // Header design
        JTableHeader header = table.getTableHeader();
        header.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20));
        header.setBackground(new Color(255, 153, 0));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createLineBorder(Color.WHITE));

        // ✅ Center only columns 0, 2, 3, 4, 5
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        int[] centerCols = {0, 2, 3, 4, 5};
        for (int col : centerCols) {
            if (col < table.getColumnCount()) { // prevent index errors
                table.getColumnModel().getColumn(col).setCellRenderer(centerRenderer);
            }
        }

        // Enable sorting and auto resize
        table.setAutoCreateRowSorter(true);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        int statusColIndex = 4; // Status column
        if (statusColIndex < table.getColumnCount()) {
            table.getColumnModel().getColumn(statusColIndex).setCellRenderer(new DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(JTable table, Object value,
                        boolean isSelected, boolean hasFocus,
                        int row, int column) {
                    Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                    if (value != null) {
                        String val = value.toString();
                        switch (val) {
                            case "Settled":
                                c.setForeground(Color.GREEN);
                                break;
                            case "Unsettled":
                                c.setForeground(Color.RED);
                                break;
                            default:
                                c.setForeground(Color.BLACK);
                        }
                    }
                    setHorizontalAlignment(SwingConstants.CENTER); // optional: center text
                    return c;
                }
            });
        }
    }

    // ✅ Apply neat modern THIN scrollbar to tbCase JScrollPane
    public static void customizeScrollBar(JScrollPane scrollPane) {
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(180, 180, 180);
                this.trackColor = Color.WHITE;
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                if (!scrollbar.isEnabled() || thumbBounds.width > thumbBounds.height) {
                    return;
                }
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(thumbColor);
                g2.fillRoundRect(
                        thumbBounds.x,
                        thumbBounds.y,
                        thumbBounds.width,
                        thumbBounds.height,
                        8, 8
                );
                g2.dispose();
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return createZeroButton();
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return createZeroButton();
            }

            private JButton createZeroButton() {
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(0, 0));
                button.setMinimumSize(new Dimension(0, 0));
                button.setMaximumSize(new Dimension(0, 0));
                return button;
            }
        });

        scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0)); // thinner
        scrollPane.getVerticalScrollBar().setUnitIncrement(16); // smooth scroll speed
    }
}
