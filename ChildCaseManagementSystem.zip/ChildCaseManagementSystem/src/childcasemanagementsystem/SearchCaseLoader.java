package childcasemanagementsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.JOptionPane;

public class SearchCaseLoader {

    private JTextField searchField;
    private JLabel enterLabel;
    private JLabel resetLabel;
    private JTable tbCase;

    public SearchCaseLoader(JTextField searchField, JLabel enterLabel, JLabel resetLabel, JTable tbCase) {
        this.searchField = searchField;
        this.enterLabel = enterLabel;
        this.resetLabel = resetLabel;
        this.tbCase = tbCase;
        init();
    }

    private void init() {
        // Real-time search on typing
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                loadCases(searchField.getText().trim());
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                loadCases(searchField.getText().trim());
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                loadCases(searchField.getText().trim());
            }
        });

        // Search on clicking the enter icon
        enterLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loadCases(searchField.getText().trim());
            }
        });

        // Reset button clears search
        resetLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchField.setText("");
                loadCases("");
            }
        });
    }

    private void loadCases(String keyword) {
        DefaultTableModel model = (DefaultTableModel) tbCase.getModel();
        model.setRowCount(0); // clear table

        String query = 
            "SELECT c.last_name, c.first_name, 'CAR' AS Category, cd.DateReported, cd.Case_Status, cd.ActionTaken " +
            "FROM child_tb c JOIN casedetailscar_tb cd ON c.childID = cd.childID " +
            "WHERE LOWER(c.last_name) LIKE ? OR LOWER(c.first_name) LIKE ? " +
            "UNION ALL " +
            "SELECT c.last_name, c.first_name, 'CICL' AS Category, cd.DateReported, cd.Case_Status, cd.ActionTaken " +
            "FROM child_tb c JOIN casedetailscicl_tb cd ON c.childID = cd.childID " +
            "WHERE LOWER(c.last_name) LIKE ? OR LOWER(c.first_name) LIKE ? " +
            "UNION ALL " +
            "SELECT c.last_name, c.first_name, 'CNSP' AS Category, cd.DateReported, cd.Case_Status, cd.ActionTaken " +
            "FROM child_tb c JOIN casedetailscnsp_tb cd ON c.childID = cd.childID " +
            "WHERE LOWER(c.last_name) LIKE ? OR LOWER(c.first_name) LIKE ? " +
            "ORDER BY last_name, first_name";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(query)) {

            String likeKeyword = "%" + keyword.toLowerCase() + "%";
            // Set parameters for CAR, CICL, CNSP
            pst.setString(1, likeKeyword);
            pst.setString(2, likeKeyword);
            pst.setString(3, likeKeyword);
            pst.setString(4, likeKeyword);
            pst.setString(5, likeKeyword);
            pst.setString(6, likeKeyword);

            ResultSet rs = pst.executeQuery();
            int caseNo = 1;
            while (rs.next()) {
                model.addRow(new Object[]{
                    caseNo++,                                   // Case No.
                    rs.getString("last_name") + ", " + rs.getString("first_name"), // Child Name
                    rs.getString("Category"),                   // Case Category
                    rs.getString("DateReported"),              // Date Reported
                    rs.getString("Case_Status"),               // Status
                    rs.getString("ActionTaken")                // Action Taken
                });
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error loading cases: " + ex.getMessage());
        }
    }
}
