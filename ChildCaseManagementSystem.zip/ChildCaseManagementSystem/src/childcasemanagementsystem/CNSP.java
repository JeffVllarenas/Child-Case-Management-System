
package childcasemanagementsystem;

public class CNSP {
    private String TypeOfViolence;
    private String Perpetrator;
    private String ReferredBy;
    private String DateReported;
    
    CNSP (String TypeOfViolence, String Perpetrator, String ReferredBy, String DateReported){
        this.TypeOfViolence = TypeOfViolence;
        this.Perpetrator = Perpetrator;
        this.ReferredBy = ReferredBy;
        this.DateReported = DateReported;
        
      
    }
    String getTypeOfViolence() {return TypeOfViolence; }
    String getPerpetrator() { return Perpetrator;}
    String getReferredBy() {return ReferredBy;}
    String getDateReported() {return DateReported;}
}
