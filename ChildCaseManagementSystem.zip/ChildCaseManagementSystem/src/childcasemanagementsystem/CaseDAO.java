package childcasemanagementsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class CaseDAO {

    private static int mapCategoryNameToId(String category) {
        if (category == null) return 0;
        switch (category.trim().toUpperCase()) {
            case "CAR": return 1;
            case "CICL": return 2;
            case "CNSP": return 3;
            default: return 0;
        }
    }

    private static String fetchCategoryNameFromChild(int childId) {
        String query = "SELECT categoryID FROM child_tb WHERE ChildID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setInt(1, childId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    int catId = rs.getInt("categoryID");
                    switch (catId) {
                        case 1: return "CAR";
                        case 2: return "CICL";
                        case 3: return "CNSP";
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean insertCaseByCategory(
            String crimeCommitted, String typesOfViolence,
            String perpetrator, String referredBy,
            String dateReported, int childId, String actionTaken,
            String category) {

        // ✅ Resolve category if null
        if (category == null || category.trim().isEmpty()) {
            category = fetchCategoryNameFromChild(childId);
            if (category == null) {
                JOptionPane.showMessageDialog(null, "⚠ Category not found for ChildID " + childId);
                return false;
            }
        }
        category = category.trim().toUpperCase();
        int categoryId = mapCategoryNameToId(category);

        if (categoryId == 0) {
            JOptionPane.showMessageDialog(null, " Invalid category: " + category);
            return false;
        }

        String sql;
        switch (category) {
            case "CAR":
                sql = "INSERT INTO casedetailscar_tb "
                        + "(ChildID, CategoryID, Committed_Crime, ReferredBy, DateReported, ActionTaken) "
                        + "VALUES (?, ?, ?, ?, ?, ?)";
                break;

            case "CICL":
                sql = "INSERT INTO casedetailscicl_tb "
                        + "(ChildID, CategoryID, Committed_Crime, ReferredBy, DateReported, ActionTaken) "
                        + "VALUES (?, ?, ?, ?, ?, ?)";
                break;

            case "CNSP":
                sql = "INSERT INTO casedetailscnsp_tb "
                        + "(ChildID, CategoryID, TypeOfViolence, Perpetrator, ReferredBy, DateReported, ActionTaken) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)";
                break;

            default:
                JOptionPane.showMessageDialog(null, "⚠ Unknown category: " + category);
                return false;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            switch (category) {
                case "CAR":
                case "CICL":
                    pst.setInt(1, childId);
                    pst.setInt(2, categoryId);
                    pst.setString(3, crimeCommitted);
                    pst.setString(4, referredBy);
                    pst.setString(5, dateReported);
                    pst.setString(6, actionTaken);
                    break;

                case "CNSP":
                    pst.setInt(1, childId);
                    pst.setInt(2, categoryId);
                    pst.setString(3, typesOfViolence);
                    pst.setString(4, perpetrator);
                    pst.setString(5, referredBy);
                    pst.setString(6, dateReported);
                    pst.setString(7, actionTaken);
                    break;
            }

            int rows = pst.executeUpdate();
            if (rows > 0) {
                System.out.println("✅ Case details successfully inserted for category: " + category);
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "❌ Insert failed: no rows affected");
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "❌ Failed to insert case details: " + e.getMessage());
            return false;
        }
    }
}
